package gov.nih.nci.ncicb.cadsr;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

import gov.nih.nci.ncicb.cadsr.dao.*;
import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;
import java.lang.reflect.Constructor;

public class CadsrTestCase extends TestCase 
{

  static {
    ApplicationContextFactory.init("applicationContext.xml");
  }

  public CadsrTestCase() {
    super();
  }

  public CadsrTestCase(String name) {
    super(name);
  }


  public static Test suite()
  {
    TestSuite suite = new TestSuite();

    String[] tcs = TestCaseProperties.getTestList();
    for(int i=0; i<tcs.length; i++) {
      try {
	String[] next = tcs[i].split("\\.");
	Class clazz = Class.forName(TestCaseProperties.getFullClassName(next[0]));

	// retrieve class constructor
	Class[] types = new Class[1];
	types[0] = String.class;
	Constructor conzt = clazz.getConstructor(types);
	
	String[] args = new String[1];
	args[0] = next[1];
	System.out.println("Adding Test to Suite: " + next[0] + "." + next[1]);
	suite.addTest((TestCase)conzt.newInstance(args));
      } catch (Exception e){
	e.printStackTrace();
      } // end of try-catch
    }

//     suite.addTest(new ContextDAOTest("testFindByName"));
//     suite.addTest(new ContextDAOTest("testFindByName"));
//     suite.addTest(new ValueDomainDAOTest("testFindByName"));
//     suite.addTest(new ContextDAOTest("testFindByName"));
//     suite.addTest(new ValueDomainDAOTest("testFindByNameLike"));
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {

    TestRunner.run(suite());

//     TestRunner.run(CadsrTestCase.class);


//     ContextDAOTest.main(args);
//     ValueDomainDAOTest.main(args);
//     DataElementDAOTest.main(args);
//     ObjectClassDAOTest.main(args);
//     PropertyDAOTest.main(args);
//     DataElementConceptDAOTest.main(args);
//     ClassificationSchemeDAOTest.main(args);
//     CRFDAOTest.main(args);
  }
  
}