package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;

import gov.nih.nci.ncicb.cadsr.model.ValueDomain;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;

public class ValueDomainDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(ValueDomainDAOTest.class.getName());
  


  public ValueDomainDAOTest()
  {
  }
  
  public ValueDomainDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFindByNameLike()
    throws Exception
  {
    String name = "TESTLOINC%";
    List list = valueDomainDAO.findByNameLike(name);
    assertTrue("ValueDomain " + name + " does not Exist", list.size() > 0);
  }

  public void testFindByName()
    throws Exception
  {
    String name = TestCaseProperties.getTestData("testFindByName.name");
    System.out.println("Searching for VD: " + name);
    ValueDomain valueDomain = valueDomainDAO.findByName(name);
    assertNotNull("ValueDomain " + name + " does not Exist", valueDomain);
  }

  public void testFindPermissibleValues() 
    throws Exception { 
    
    String name = TestCaseProperties.getTestData("testFindPermissibleValues.vd.name");
    System.out.println("Searching for VD: " + name);
    ValueDomain valueDomain = valueDomainDAO.findByName(name);
    assertNotNull("ValueDomain " + name + " does not Exist", valueDomain);
    
    List pvs = valueDomainDAO.getPermissibleValues(valueDomain.getId());
    assertTrue("ValueDomain has too few PVs: " + pvs.size(), pvs.size() > (new Integer(TestCaseProperties.getTestData("testFindPermissibleValues.result")).intValue()));

  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(ValueDomainDAOTest.class);
    return suite;
  }

  public static void main(String[] args) {
    TestRunner.run(ValueDomainDAOTest.class);
  }


}