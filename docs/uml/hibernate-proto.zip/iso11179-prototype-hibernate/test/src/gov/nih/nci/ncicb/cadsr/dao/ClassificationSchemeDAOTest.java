package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.dao.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class ClassificationSchemeDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(ClassificationSchemeDAOTest.class.getName());
  
  public ClassificationSchemeDAOTest()
  {
  }
  
  public ClassificationSchemeDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFind()
    throws Exception
  {
    ClassificationScheme o = new ClassificationScheme();
    Context context = getContext("CTEP");

    o.setContext(context);
    o.setLongName("TYPE OF%");

    List result = classificationSchemeDAO.find(o);

    System.out.println("Found " + result.size() + " CS");

    assertTrue("no CS found !! ", result.size() > 0);

    ClassificationScheme cs = (ClassificationScheme)result.get(0);

    List csi = classificationSchemeDAO.getCsis(cs.getId());
    
    System.out.println("Found " + csi.size() + " CSI");

    assertTrue("no CSI found !! ", csi.size() > 0);
    

  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(ClassificationScheme.class);
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(ClassificationSchemeDAOTest.class);
  }
 
}