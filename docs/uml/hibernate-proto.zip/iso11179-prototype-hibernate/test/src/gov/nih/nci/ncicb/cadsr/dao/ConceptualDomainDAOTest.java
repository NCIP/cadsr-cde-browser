package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;

import gov.nih.nci.ncicb.cadsr.model.ConceptualDomain;
import gov.nih.nci.ncicb.cadsr.model.Context;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;

public class ConceptualDomainDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(ConceptualDomainDAOTest.class.getName());
  


  public ConceptualDomainDAOTest()
  {
  }
  
  public ConceptualDomainDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFind()
    throws Exception
  {
    ConceptualDomain cd = new ConceptualDomain();
    cd.setLongName(TestCaseProperties.getTestData("testFind.name"));

    System.out.println("Searching for CD: " + cd.getLongName());
    List list = conceptualDomainDAO.find(cd);

    int result = 1;

    try {
      result = Integer.parseInt(TestCaseProperties.getTestData("testFind.result"));
    } catch (Exception e){
    } // end of try-catch

    assertTrue("Wrong number of CD found:  " + list.size(), list.size() == result);
  }

  public void testAdd() {
    ConceptualDomain cd = new ConceptualDomain();

    Context context = getContext(TestCaseProperties.getTestData("testAdd.context.name"));
    cd.setContext(context);

    cd.setLongName(TestCaseProperties.getTestData("testAdd.cd.longName"));
    cd.setPreferredName(TestCaseProperties.getTestData("testAdd.cd.preferredName"));
    cd.setPreferredDefinition(TestCaseProperties.getTestData("testAdd.cd.definition"));
    cd.setVersion(new Float(1.0f));
    cd.setWorkflowStatus(TestCaseProperties.getTestData("testAdd.cd.workflowStatus"));
    
    System.out.println("Creating CD: longName=" + cd.getPreferredName());
    System.out.println("pref Name=" + cd.getPreferredName());
    String pk = adminComponentDAO.create(cd);

//     ConceptualDomain o = new ConceptualDomain();
//     o.setContext(context);
//     o.setLongName(TestCaseProperties.getTestData("testAdd.cd.longName"));

//     List result = conceptualDomainDAO.find(o);

//     System.out.println("Found " + result.size() + " CD");
//     assertTrue("Wrong number of CD found:  " + result.size(), result.size() == 1);
    
  }

  public void testDelete() {
    Context context = getContext(TestCaseProperties.getTestData("testDelete.context.name"));

    ConceptualDomain o = new ConceptualDomain();
    o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testDelete.cd.longName"));

    System.out.println("Deleting CD with longName=" + o.getLongName());

    List result = conceptualDomainDAO.find(o);
    o = (ConceptualDomain)result.get(0);

    adminComponentDAO.setDeleted(o);

//     o = new ConceptualDomain();
//     o.setContext(context);
//     o.setLongName(TestCaseProperties.getTestData("testDelete.cd.longName"));

//     result = conceptualDomainDAO.find(o);
//     System.out.println("Found " + result.size() + " results");
    
//     assertTrue("ConceptualDomain FOUND !! ", result.size() == 0);

  }


}