package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.Context;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class ContextDAOTest extends TestCase
{

  protected static Log log = LogFactory.getLog(ContextDAOTest.class.getName());
  
  private ContextDAO contextDAO;


  public ContextDAOTest()
  {
  }
  
  public ContextDAOTest(String testName)
  {
    super(testName);
  }
  
  protected void setUp() throws Exception
  {
    contextDAO = (ContextDAO) ApplicationContextFactory.getApplicationContext().getBean("contextDAO");
  }
  
  public void testFindAll()
    throws Exception
  {
    List list = contextDAO.findAll();
    assertTrue("Context list too short or too long", list.size() > 10 && list.size() < 20);
  }

  public void testFindByName()
    throws Exception
  {
    String name = "TEST";
    Context context = contextDAO.findByName(name);
    assertNotNull("Context caCORE does not Exist", context);
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite();
    suite.addTest(new ContextDAOTest("testFindAll"));
    suite.addTest(new ContextDAOTest("testFindByName"));
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(ContextDAOTest.class);
  }
 
}