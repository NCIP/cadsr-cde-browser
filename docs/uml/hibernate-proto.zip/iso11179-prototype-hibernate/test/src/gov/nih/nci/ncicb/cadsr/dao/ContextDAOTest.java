package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.Context;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;
import gov.nih.nci.ncicb.cadsr.*;
import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;

import org.jboss.aop.Advised;
import org.jboss.aop.Advisor;

public class ContextDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(ContextDAOTest.class.getName());
  
  public ContextDAOTest()
  {
  }
  
  public ContextDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFindAll()
    throws Exception
  {
    List list = contextDAO.findAll();
    assertTrue("Context list too short or too long", list.size() > 10 && list.size() < 20);
  }

  public void testFindByName()
    throws Exception
  {

    String name = TestCaseProperties.getTestData("testFindByName.name");
    System.out.println("Searching for Context: " + name);
    Context context = contextDAO.findByName(name);
    assertNotNull("Context " + name + " does not Exist", context);
  }

  public static Test suite()
  {
//     TestSuite suite = new TestSuite(Context.class);
//     return suite;
    
    TestSuite suite = new TestSuite();
    suite.addTest(new ContextDAOTest("testFindByName"));

    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(suite());
  }
 
}