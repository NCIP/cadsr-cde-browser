package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;
import gov.nih.nci.ncicb.cadsr.dao.CriteriaBuilder;

import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;

import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;
import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class DataElementDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(DataElementDAOTest.class.getName());
  
  public DataElementDAOTest()
  {
  }
  
  public DataElementDAOTest(String testName)
  {
    super(testName);
  }

  public void testFind()
    throws Exception
  {
    DataElement o = new DataElement();
    Context context = getContext(TestCaseProperties.getTestData("testFind.context.name"));

    o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testFind.longName"));

    List result = dataElementDAO.find(o);

    System.out.println("Found " + result.size() + " results");

    assertTrue("no Data Elements found !! ", result.size() > 0);
  }

  public void testClassificationSchemes() {
    DataElement o = new DataElement();
    Context context = getContext(TestCaseProperties.getTestData("testClassificationSchemes.context.name"));

    o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testClassificationSchemes.longName"));

    List result = dataElementDAO.find(o);
    assertTrue("no Data Elements found !! ", result.size() > 0);

    result = adminComponentDAO.getClassificationSchemes((DataElement)result.get(0));

    System.out.println("Found " + result.size() + " CS for DE");
    assertTrue("no CS found !! ", result.size() > 0);
  }

  public void testRefDocs() {
    DataElement o = new DataElement();

    Context context = getContext(TestCaseProperties.getTestData("testRefDocs.context.name"));
    o.setLongName(TestCaseProperties.getTestData("testRefDocs.longName"));

    List result = dataElementDAO.find(o);

    assertTrue("no Data Elements found !! ", result.size() > 0);

    result = adminComponentDAO.getReferenceDocuments((DataElement)result.get(0));

    System.out.println("Found " + result.size() + " docs for DE");
    assertTrue("Wrong number of ref docs found !! " + result.size(), result.size() == Integer.parseInt(TestCaseProperties.getTestData("testRefDocs.result")));
    
    
  }

  public void testAdd() {
    System.out.println("-- TESTADD --");

    DataElement de = new DataElement();
    DataElementConcept dec = new DataElementConcept();
    ValueDomain vd = new ValueDomain();

    Context context = getContext(TestCaseProperties.getTestData("testAdd.context.name"));

    dec.setContext(context);
    dec.setLongName(TestCaseProperties.getTestData("testAdd.dec.longName"));
    dec = (DataElementConcept)(dataElementConceptDAO.find(dec).get(0));
    assertTrue("no DEC Found:  " + dec.getLongName(), dec != null);

    vd.setContext(context);
    vd.setLongName(TestCaseProperties.getTestData("testAdd.vd.longName"));
    vd = (ValueDomain)(valueDomainDAO.find(vd).get(0));
    assertNotNull("No VD Found: " + vd.getLongName(), vd);

    de.setContext(context);
    de.setLongName(TestCaseProperties.getTestData("testAdd.de.longName"));
    de.setPreferredName(TestCaseProperties.getTestData("testAdd.de.preferredName"));
    de.setPreferredDefinition(TestCaseProperties.getTestData("testAdd.de.definition"));
    de.setDataElementConcept(dec);
    de.setValueDomain(vd);
    de.setVersion(new Float(1.0f));

    de.setWorkflowStatus(TestCaseProperties.getTestData("testAdd.de.workflowStatus"));

    System.out.println("Creating DE: longName=" + de.getPreferredName());
    System.out.println("pref Name=" + de.getPreferredName());
    String pk = adminComponentDAO.create(de);

//     DataElement o = new DataElement();
//     o.setContext(context);
//     o.setLongName(TestCaseProperties.getTestData("testAdd.de.longName"));

//     List result = dataElementDAO.find(o);

//     System.out.println("Found " + result.size() + " DEs");
//     assertTrue("no Data Elements found !! ", result.size() == 1);
    
  }

  public void testUpdate() {
    Context context = getContext(TestCaseProperties.getTestData("testUpdate.context.name"));

    DataElement o = new DataElement();
    o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testUpdate.de.longName"));

    List result = dataElementDAO.find(o);

    System.out.println("Found " + result.size() + " DEs");
    assertTrue("no Data Elements found !! ", result.size() == 1);

    o = (DataElement)result.get(0);

    o.setLongName(TestCaseProperties.getTestData("testUpdate.de.new.longName"));
    o.setPreferredName(TestCaseProperties.getTestData("testUpdate.de.new.preferredName"));

    System.out.println("Updating DE to longName=" + o.getLongName());
    System.out.println("PrefName=" + o.getPreferredName());
    adminComponentDAO.update(o);

//     result = dataElementDAO.find(o);

//     System.out.println("Found " + result.size() + " DEs");
//     assertTrue("no Data Elements found !! ", result.size() == 1);
  }


  public void testDelete() {
    Context context = getContext(TestCaseProperties.getTestData("testDelete.context.name"));

    DataElement o = new DataElement();
    o.setContext(context);

    o.setLongName(TestCaseProperties.getTestData("testDelete.de.longName"));

    System.out.println("Deleting DE with longName=" + o.getLongName());
    List result = dataElementDAO.find(o);
    o = (DataElement)result.get(0);

    adminComponentDAO.setDeleted(o);

//     o = new DataElement();
//     o.setContext(context);
//     o.setLongName(TestCaseProperties.getTestData("testDelete.de.longName"));

//     result = dataElementDAO.find(o);
//     System.out.println("Found " + result.size() + " results");
    
//     assertTrue("DataElement FOUND !! ", result.size() == 0);

  }

  public void testFindByCriteria()
    throws Exception
  {
    System.out.println("Criterias: ");
    final String longName = TestCaseProperties.getTestData("testFindByCriteria.longName");
    final String prefName = TestCaseProperties.getTestData("testFindByCriteria.preferredName");

    CriteriaBuilder cb = new CriteriaBuilder() {
	public void populate(Criteria criteria) {
	  System.out.println("Criterias: ");
	  System.out.println("longName: " + longName);
	  System.out.println("prefName: " + prefName);
	  criteria.add(Expression.or(
			 Expression.like("longName", longName),
			 Expression.like("preferredName", prefName)));
	  
	}
      };
    
    List result = dataElementDAO.findByCriteria(cb);
    System.out.println("Found " + result.size() + " results");

    DataElement de = (DataElement)result.get(0);
    System.out.println("longName: " + de.getLongName());
    System.out.println("prefName: " + de.getPreferredName());

    assertTrue("Found wrong number of DE: " + result.size(), result.size() == Integer.parseInt(TestCaseProperties.getTestData("testFindByCriteria.result")));
  }



  public static Test suite()
  {
    TestSuite suite = new TestSuite(DataElement.class);
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(DataElementDAOTest.class);
  }
 
}