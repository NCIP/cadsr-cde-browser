package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class DataElementDAOTest extends TestCase
{

  protected static Log log = LogFactory.getLog(DataElementDAOTest.class.getName());
  
  private DataElementDAO dataElementDAO;


  public DataElementDAOTest()
  {
  }
  
  public DataElementDAOTest(String testName)
  {
    super(testName);
  }
  
  protected void setUp() throws Exception
  {
    dataElementDAO = (DataElementDAO) ApplicationContextFactory.getApplicationContext().getBean("dataElementDAO");
  }
  
  public void testFind()
    throws Exception
  {
    DataElement de = new DataElement();
    Context context = new Context();

    context.setContextId("99BA9DC8-2095-4E69-E034-080020C9C0E0"); // CTEP on CBTEST

    de.setContext(context);
    de.setLongName("(specify%");

    List result = dataElementDAO.find(de);

    assertTrue("no Data Elements found !! ", result.size() > 0);
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(DataElement.class);
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(DataElementDAOTest.class);
  }
 
}