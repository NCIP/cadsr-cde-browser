package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class DataElementDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(DataElementDAOTest.class.getName());
  
  public DataElementDAOTest()
  {
  }
  
  public DataElementDAOTest(String testName)
  {
    super(testName);
  }

  public void testFind()
    throws Exception
  {
    DataElement o = new DataElement();
    Context context = getContext("CTEP");

    o.setContext(context);
    o.setLongName("(specify%");

    List result = dataElementDAO.find(o);

    assertTrue("no Data Elements found !! ", result.size() > 0);
  }

  public void testClassificationSchemes()
    throws Exception {

    DataElement o = new DataElement();
    Context context = getContext("caCORE");

    o.setContext(context);
    o.setLongName("abbrev%");

    List result = dataElementDAO.find(o);
    assertTrue("no Data Elements found !! ", result.size() > 0);

    result = adminComponentDAO.getClassificationSchemes((DataElement)result.get(0));

    System.out.println("Found " + result.size() + " CS for DE");
    assertTrue("no CS found !! ", result.size() > 0);
  }

  public void testAdd() {
    DataElement de = new DataElement();
    DataElementConcept dec = new DataElementConcept();
    ValueDomain vd = new ValueDomain();

    Context context = getContext("TEST");

    dec.setContext(context);
    dec.setLongName("DEC");
    dec = (DataElementConcept)(dataElementConceptDAO.find(dec).get(0));

    vd.setContext(context);
    vd.setLongName("Day");
    vd = (ValueDomain)(valueDomainDAO.find(vd).get(0));

    de.setContext(context);
    de.setLongName("CHRISTOPHE TEST");
    de.setPreferredName("CHRISTOPHE_TEST");
    de.setPreferredDefinition("The best definition I could come up with.");
    de.setDataElementConcept(dec);
    de.setValueDomain(vd);
    de.setVersion(new Float(1.0f));

    de.setWorkflowStatus("DRAFT NEW");

    String pk = dataElementDAO.create(de);

    DataElement o = new DataElement();
    o.setContext(context);
    o.setLongName("CHRISTOPHE%");

    List result = dataElementDAO.find(o);
    System.out.println("Found " + result.size() + " DEs");

    assertTrue("no Data Elements found !! ", result.size() > 0);

    
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(DataElement.class);
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(DataElementDAOTest.class);
  }
 
}