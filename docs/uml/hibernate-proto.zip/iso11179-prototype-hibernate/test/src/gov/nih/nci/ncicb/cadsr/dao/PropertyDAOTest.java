package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class PropertyDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(PropertyDAOTest.class.getName());
  
  public PropertyDAOTest()
  {
  }
  
  public PropertyDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFind()
    throws Exception
  {
    Property o = new Property();
    Context context = getContext("CTEP");

    o.setContext(context);
    o.setLongName("Adh%");

    List result = propertyDAO.find(o);

    System.out.println("Found " + result.size() + " Props");

    assertTrue("no PROPERTY found !! ", result.size() > 0);
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(Property.class);
    return suite;
  }

  public static void main(String[] args) {
    TestRunner.run(PropertyDAOTest.class);
  }
 
}