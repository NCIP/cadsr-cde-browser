package gov.nih.nci.ncicb.cadsr.aop;

import org.jboss.aop.*;
import org.jboss.aop.joinpoint.*;
import org.jboss.aop.advice.*;
import java.lang.reflect.*;

import gov.nih.nci.ncicb.cadsr.TestCaseProperties;

public class PropertiesInterceptor implements Interceptor
{
  public String getName() { 
    return "TracingInterceptor";
  }
  
  public Object invoke(Invocation invocation) 
    throws Throwable
  {

    MethodInvocation   methodInvoke  = (MethodInvocation)invocation;

    String callingMethod = methodInvoke.method.getName();
    Object[] args = methodInvoke.arguments;
    String param = (String)args[0];
    System.out.println("param before modif: " + param);
    param = callingMethod + "." + param;
    args[0] = param;
    System.out.println("param after modif: " + param);

    return invocation.invokeNext(); 
    
  }
}
