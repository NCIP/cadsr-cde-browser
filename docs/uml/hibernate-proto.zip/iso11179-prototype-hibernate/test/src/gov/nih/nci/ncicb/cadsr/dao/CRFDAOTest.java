package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class CRFDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(PropertyDAOTest.class.getName());
  
  public CRFDAOTest()
  {
  }
  
  public CRFDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFind()
    throws Exception
  {
    CaseReportForm o = new CaseReportForm();
    Context context = getContext("CTEP");

    String name = "Abnormal%";

    o.setContext(context);
    o.setLongName(name);

    List result = contentObjectDAO.find(o);

    System.out.println("Found " + result.size() + " CRFs");

    assertTrue("no CRF found !! ", result.size() > 0);

    CaseReportForm crf = (CaseReportForm)result.get(0);

    result = contentObjectDAO.getChildren(crf.getId());
    
    int nbMods = 0, nbInst = 0, nbUnknown=0;
    
    for(int i=0; i<result.size(); i++) {
      ContentObject co = (ContentObject)result.get(0);
      if(co instanceof Module) {
	int nbQues = 0;
	nbMods++;
// 	Module mod = (Module)co;
	List modRecs = contentObjectDAO.getChildren(co.getId());
	for(int j=0; j<modRecs.size(); j++) {
	  ContentObject co2 = (ContentObject)modRecs.get(j);
	  if(co2 instanceof Question) {
	    nbQues++;
	    int nbVVs = 0;
	    List quesVVs = contentObjectDAO.getChildren(co2.getId());
	    for(int k=0; k<quesVVs.size(); k++) {
	      ContentObject co3 = (ContentObject)quesVVs.get(k);
	      if(co3 instanceof ValidValue) {
		nbVVs++;
	      } else {
		System.out.println(co3.getClass().getName());
	      }
	    }
	    System.out.println("Found " + nbVVs + " VVs");
	  } else {
	    System.out.println(co2.getClass().getName());
	  }
	}
	System.out.println("Found " + nbQues + " Questions");
	assertTrue("Module had no questions", nbQues > 0);
      }
      else if(co instanceof CRFInstruction)
	nbInst++;
      else
	nbUnknown++;
    }

    System.out.println("Found " + nbMods + " Modules " );

    assertTrue("Unknow children in CRF", nbUnknown == 0);
    assertTrue("Did not find Module for Form ", nbMods > 0);

    

  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(Property.class);
    return suite;
  }

  public static void main(String[] args) {
    TestRunner.run(CRFDAOTest.class);
  }
 
}