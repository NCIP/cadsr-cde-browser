package gov.nih.nci.ncicb.cadsr.aop;

import org.jboss.aop.*;
import org.jboss.aop.joinpoint.*;
import org.jboss.aop.advice.*;
import java.lang.reflect.*;

import gov.nih.nci.ncicb.cadsr.TestCaseProperties;

public class TracingInterceptor implements Interceptor
{
  public String getName() { 
    return "TracingInterceptor";
  }
  
  public Object invoke(Invocation invocation) 
    throws Throwable
  {
    MethodInvocation   methodInvoke  = null;
    
    //Must ensure that this is only bound to method
    // invocations, else ClassCastException will ensue
    methodInvoke = (MethodInvocation)invocation;

    TestCaseProperties.addCount(methodInvoke.method.getDeclaringClass().getName(), methodInvoke.actualMethod.getName());	

    return invocation.invokeNext(); 
    
  }
}
