package gov.nih.nci.ncicb.cadsr.aop;

import org.jboss.aop.*;
import org.jboss.aop.joinpoint.*;
import org.jboss.aop.advice.*;
import java.lang.reflect.*;

import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;

public class TracingInterceptor implements Interceptor
{
  public String getName() { 
    return "TracingInterceptor";
  }
  
  public Object invoke(Invocation invocation) 
    throws Throwable
  {
    MethodInvocation   methodInvoke  = null;
    
    //Must ensure that this is only bound to method
    // invocations, else ClassCastException will ensue
    methodInvoke = (MethodInvocation)invocation;

    TestCaseProperties.addCount(methodInvoke.method.getDeclaringClass().getName(), methodInvoke.actualMethod.getName());	


    System.out.println("TEST: "  + methodInvoke.method.getDeclaringClass().getName() + "." + methodInvoke.method.getName());
    

//     System.out.println("CALLED: " + ((MethodCalledByMethodInvocation)invocation).calledMethod);

//     Interceptor[] ceptors = invocation.getInterceptors();
//     for(int i=0; i<ceptors.length; i++) {
//       System.out.println("Interceptor: " + ceptors[i].getName());
//     }

    return invocation.invokeNext(); 
    
  }
}
