package gov.nih.nci.ncicb.cadsr;

import java.util.*;
import java.io.*;

public class TestCaseProperties {

  private static Properties testData = new Properties();
  private static Properties classMapping = new Properties();
  protected static HashMap methodCount = new HashMap();

  
  
  static  {
    try {
      java.net.URL url = ClassLoader.getSystemResource("testData.properties");
      testData.load(url.openStream());

      classMapping.load(ClassLoader.getSystemResource("classMapping.properties").openStream());
    } catch (IOException e){
      System.out.println("Can't open properties File");
      System.exit(1);
    } // end of try-catch
  }

  public static String getProperty(String name) {
    return testData.getProperty(name);
  }

  public static String getTestData(String name) {
    StackTraceElement st = new Exception().getStackTrace()[1]; 
    String className = st.getClassName().substring(st.getClassName().lastIndexOf(".") + 1);
    String prefix = className + "."; // + st.getMethodName();

    String countStr = className + "." + st.getMethodName();

    Integer i = (Integer)methodCount.get(countStr);
    int count = 0;
    if(i != null)
      count = i.intValue();
    
    String property = null;
    while(count != -1) {
      property = testData.getProperty(prefix + name + "." + count);
      count--;
      if(property != null) 
	return property;
    }

    return property;
    
  }

  public static void addCount(String cName, String mName) {
    String className = cName.substring(cName.lastIndexOf(".") + 1);
    String prefix = className + "." + mName;

    Integer i = (Integer)methodCount.get(prefix);

//     System.out.println("Adding to count for: " + prefix);
    if(i == null)
      methodCount.put(prefix, new Integer(0));
    else 
      methodCount.put(prefix, new Integer(i.intValue() + 1));

  }

  public static String getFullClassName(String className) {
    return classMapping.getProperty(className) + "." + className;
  }

  public static String[] getTestList() {

    ArrayList list = new ArrayList();

    Enumeration enum = testData.propertyNames();

    String lastTest = "";
    String lastCount = "";
    while(enum.hasMoreElements()) {
      String propName = (String)enum.nextElement();
      int ind = propName.indexOf(".");
      ind = propName.indexOf(".", ind+1);
      String testName = propName.substring(0, ind);
      String testCount = propName.substring(propName.lastIndexOf(".") + 1);
      // is this new test?
      if(!testName.equals(lastTest) || !testCount.equals(lastCount)) {
	list.add(testName);
      }
      lastTest = testName;
      lastCount = testCount;
    }

    String[] result = new String[list.size()];
    list.toArray(result);
    return result;
  }

}