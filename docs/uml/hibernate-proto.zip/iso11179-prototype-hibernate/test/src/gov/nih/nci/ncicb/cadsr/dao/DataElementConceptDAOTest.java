package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;


import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;
import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class DataElementConceptDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(DataElementConceptDAOTest.class.getName());
  


  public DataElementConceptDAOTest()
  {
  }
  
  public DataElementConceptDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFind()
    throws Exception
  {
    DataElementConcept o = new DataElementConcept();

    Context context = getContext(TestCaseProperties.getTestData("testFind.context.name"));

    o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testFind.longName"));
    o.setLatestVersionIndicator(AdminComponent.LATEST_VERSION_IND_YES);

    List result = dataElementConceptDAO.find(o);

    System.out.println("Found " + result.size() + " DECs");

    assertTrue("no Data Elements found !! ", result.size() > 0);
  }

  public void testDECRelationships() {
    DataElementConcept o = new DataElementConcept();
    Context context = getContext(TestCaseProperties.getTestData("testDECRelationships.context.name"));

    o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testDECRelationships.longName"));
    o.setLatestVersionIndicator(AdminComponent.LATEST_VERSION_IND_YES);

    List result = dataElementConceptDAO.find(o);

    assertTrue("no Data Elements found !! ", result.size() > 0);

    DataElementConcept dec = (DataElementConcept)result.get(0);

    result = dataElementConceptDAO.getRelatedDECs(dec.getId());
    System.out.println("Found " + result.size() + " related DECs");

    assertTrue("not enough relationships found !! ", result.size() > 5);
  }
 
}