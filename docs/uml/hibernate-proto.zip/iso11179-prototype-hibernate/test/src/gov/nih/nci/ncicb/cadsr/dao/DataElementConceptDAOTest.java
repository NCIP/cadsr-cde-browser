package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class DataElementConceptDAOTest extends TestCase
{

  protected static Log log = LogFactory.getLog(DataElementConceptDAOTest.class.getName());
  
  private DataElementConceptDAO dataElementConceptDAO;


  public DataElementConceptDAOTest()
  {
  }
  
  public DataElementConceptDAOTest(String testName)
  {
    super(testName);
  }
  
  protected void setUp() throws Exception
  {
    dataElementConceptDAO = (DataElementConceptDAO) ApplicationContextFactory.getApplicationContext().getBean("dataElementConceptDAO");
  }
  
  public void testFind()
    throws Exception
  {
    DataElementConcept o = new DataElementConcept();
    Context context = new Context();

    context.setContextId("99BA9DC8-2095-4E69-E034-080020C9C0E0"); // CTEP on CBTEST

    o.setContext(context);
    o.setLongName("(specify%");

    List result = dataElementConceptDAO.find(o);

    System.out.println("Found " + result.size() + " DECs");

    assertTrue("no Data Elements found !! ", result.size() > 0);
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(DataElementConcept.class);
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(DataElementConceptDAOTest.class);
  }
 
}