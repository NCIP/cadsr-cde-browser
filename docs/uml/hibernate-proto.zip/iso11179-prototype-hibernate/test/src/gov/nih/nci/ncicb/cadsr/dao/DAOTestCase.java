package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import java.util.Properties;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class DAOTestCase extends TestCase
{

  protected AdminComponentDAO adminComponentDAO;
  protected DataElementDAO dataElementDAO;
  protected ContextDAO contextDAO;
  protected DataElementConceptDAO dataElementConceptDAO;
  protected ValueDomainDAO valueDomainDAO;
  protected PropertyDAO propertyDAO;
  protected ObjectClassDAO objectClassDAO;
  protected ClassificationSchemeDAO classificationSchemeDAO;
  protected ContentObjectDAO contentObjectDAO;

  protected Properties testData = new Properties();

  public DAOTestCase() {

  }

  public DAOTestCase(String name) {
    super(name);
  }

  protected void setUp() throws Exception
  {
    contextDAO = (ContextDAO) ApplicationContextFactory.getApplicationContext().getBean("contextDAO");
    dataElementDAO = (DataElementDAO) ApplicationContextFactory.getApplicationContext().getBean("dataElementDAO");
    adminComponentDAO = (AdminComponentDAO) ApplicationContextFactory.getApplicationContext().getBean("adminComponentDAO");
    dataElementConceptDAO = (DataElementConceptDAO) ApplicationContextFactory.getApplicationContext().getBean("dataElementConceptDAO");
    valueDomainDAO = (ValueDomainDAO) ApplicationContextFactory.getApplicationContext().getBean("valueDomainDAO");
    propertyDAO = (PropertyDAO) ApplicationContextFactory.getApplicationContext().getBean("propertyDAO");
    objectClassDAO = (ObjectClassDAO) ApplicationContextFactory.getApplicationContext().getBean("objectClassDAO");
    classificationSchemeDAO = (ClassificationSchemeDAO) ApplicationContextFactory.getApplicationContext().getBean("classificationSchemeDAO");
    contentObjectDAO = (ContentObjectDAO) ApplicationContextFactory.getApplicationContext().getBean("contentObjectDAO");


    java.net.URL url = ClassLoader.getSystemResource("testData.properties");
    testData.load(url.openStream());
  }

  protected Context getContext(String name) {
    
    return contextDAO.findByName(name);

  }

}