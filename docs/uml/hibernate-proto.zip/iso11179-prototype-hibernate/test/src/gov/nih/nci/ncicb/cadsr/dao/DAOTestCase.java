package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;


public class DAOTestCase extends TestCase
{

  protected static AdminComponentDAO adminComponentDAO;
  protected static DataElementDAO dataElementDAO;
  protected static ContextDAO contextDAO;
  protected static DataElementConceptDAO dataElementConceptDAO;
  protected static ValueDomainDAO valueDomainDAO;
  protected static PropertyDAO propertyDAO;
  protected static ObjectClassDAO objectClassDAO;
  protected static ClassificationSchemeDAO classificationSchemeDAO;
  protected static ContentObjectDAO contentObjectDAO;


  static {
    System.out.println("Loading ContextDAO bean");
    contextDAO = (ContextDAO) ApplicationContextFactory.getApplicationContext().getBean("contextDAO");


    System.out.println("Loading DataElementDAO bean");
    dataElementDAO = (DataElementDAO) ApplicationContextFactory.getApplicationContext().getBean("dataElementDAO");

    System.out.println("Loading AdminComponentDAO bean");
    adminComponentDAO = (AdminComponentDAO) ApplicationContextFactory.getApplicationContext().getBean("adminComponentDAO");

    System.out.println("Loading DataElementConceptDAO bean");
    dataElementConceptDAO = (DataElementConceptDAO) ApplicationContextFactory.getApplicationContext().getBean("dataElementConceptDAO");

    System.out.println("Loading VDDAO bean");
    valueDomainDAO = (ValueDomainDAO) ApplicationContextFactory.getApplicationContext().getBean("valueDomainDAO");

    System.out.println("Loading PropertyDAO bean");
    propertyDAO = (PropertyDAO) ApplicationContextFactory.getApplicationContext().getBean("propertyDAO");

    System.out.println("Loading ObjectClassDAO bean");
    objectClassDAO = (ObjectClassDAO) ApplicationContextFactory.getApplicationContext().getBean("objectClassDAO");

    System.out.println("Loading CSDAO bean");
    classificationSchemeDAO = (ClassificationSchemeDAO) ApplicationContextFactory.getApplicationContext().getBean("classificationSchemeDAO");

    System.out.println("Loading ContentObjectDAO bean");
    contentObjectDAO = (ContentObjectDAO) ApplicationContextFactory.getApplicationContext().getBean("contentObjectDAO");

  }

  public DAOTestCase() {

  }

  public DAOTestCase(String name) {
    super(name);
  }

  protected void setUp() throws Exception
  {
    


  }

  protected Context getContext(String name) {
    
    return contextDAO.findByName(name);

  }



}