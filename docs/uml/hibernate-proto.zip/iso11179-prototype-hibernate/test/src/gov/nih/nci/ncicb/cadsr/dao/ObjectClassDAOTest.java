package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class ObjectClassDAOTest extends TestCase
{

  protected static Log log = LogFactory.getLog(ObjectClassDAOTest.class.getName());
  
  private ObjectClassDAO objectClassDAO;


  public ObjectClassDAOTest()
  {
  }
  
  public ObjectClassDAOTest(String testName)
  {
    super(testName);
  }
  
  protected void setUp() throws Exception
  {
    objectClassDAO = (ObjectClassDAO) ApplicationContextFactory.getApplicationContext().getBean("objectClassDAO");
  }
  
  public void testFind()
    throws Exception
  {
    ObjectClass o = new ObjectClass();
    Context context = new Context();

    context.setContextId("99BA9DC8-2095-4E69-E034-080020C9C0E0"); // CTEP on CBTEST

    o.setContext(context);
    o.setLongName("Abla%");

    List result = objectClassDAO.find(o);

    System.out.println("Found " + result.size() + " OCs");

    assertTrue("no OBJECT CLASS found !! ", result.size() > 0);
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(ObjectClass.class);
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
    TestRunner.run(ObjectClassDAOTest.class);
  }
 
}