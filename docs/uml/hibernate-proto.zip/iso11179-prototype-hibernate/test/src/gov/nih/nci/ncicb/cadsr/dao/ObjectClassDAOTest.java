package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

import gov.nih.nci.ncicb.cadsr.test.TestCaseProperties;

public class ObjectClassDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(ObjectClassDAOTest.class.getName());
  
  public ObjectClassDAOTest()
  {
  }
  
  public ObjectClassDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFind()
    throws Exception
  {
    ObjectClass o = new ObjectClass();
    Context context = getContext(TestCaseProperties.getTestData("testFind.context.name"));

    o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testFind.name"));

    List result = objectClassDAO.find(o);

    System.out.println("Found " + result.size() + " OCs");

    assertTrue("no OBJECT CLASS Found:  " + o.getLongName() , result.size() > 0);
  }

  public void testAltNames() {
    ObjectClass o = new ObjectClass();
    Context context = getContext(TestCaseProperties.getTestData("testAltNames.context.name"));

    if(context != null)
      o.setContext(context);
    o.setLongName(TestCaseProperties.getTestData("testAltNames.name"));

    List result = objectClassDAO.find(o);

    System.out.println("Found " + result.size() + " OCs");
    assertTrue("no OBJECT CLASS Found:  " + o.getLongName() , result.size() > 0);

    ObjectClass oc = (ObjectClass)result.get(0);

    result = adminComponentDAO.getDesignations(oc);

    System.out.println("Found " + result.size() + " Alt Names");
    assertTrue("no AltName Found:  " + oc.getLongName() , result.size() == Integer.parseInt(TestCaseProperties.getTestData("testAltNames.result")));
    
    
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(ObjectClass.class);
    return suite;
  }

  public static void main(String[] args) {
    TestRunner.run(ObjectClassDAOTest.class);
  }
 
}