package gov.nih.nci.ncicb.cadsr.dao;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;
import gov.nih.nci.ncicb.cadsr.model.*;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

public class ObjectClassDAOTest extends DAOTestCase
{

  protected static Log log = LogFactory.getLog(ObjectClassDAOTest.class.getName());
  
  public ObjectClassDAOTest()
  {
  }
  
  public ObjectClassDAOTest(String testName)
  {
    super(testName);
  }
  
  public void testFind()
    throws Exception
  {
    ObjectClass o = new ObjectClass();
    Context context = getContext("CTEP");

    o.setContext(context);
    o.setLongName("Abla%");

    List result = objectClassDAO.find(o);

    System.out.println("Found " + result.size() + " OCs");

    assertTrue("no OBJECT CLASS found !! ", result.size() > 0);
  }

  public static Test suite()
  {
    TestSuite suite = new TestSuite(ObjectClass.class);
    return suite;
  }

  public static void main(String[] args) {
    TestRunner.run(ObjectClassDAOTest.class);
  }
 
}