package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="VALID_VALUE"
 * 
 */
public class ValidValue extends ContentObject {


}