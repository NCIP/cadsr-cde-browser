package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;

import gov.nih.nci.ncicb.cadsr.dao.DataElementDAO;
import gov.nih.nci.ncicb.cadsr.dao.CriteriaBuilder;
import gov.nih.nci.ncicb.cadsr.model.DataElement;
import gov.nih.nci.ncicb.cadsr.model.AdminComponent;

public class DataElementDAOImpl extends BaseDAOImpl implements DataElementDAO {

  public List find(final DataElement de) {
    
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	    
	  Criteria criteria = session.createCriteria(DataElement.class);

	  AdminComponentQueryBuilder.buildCriteria(criteria, de);

	  return criteria.list();
	}
      };

    return (List)getHibernateTemplate().execute(callback);
    
  }

  public List findByCriteria(final CriteriaBuilder criteriaBuilder) {

    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException {
	  Criteria criteria = session.createCriteria(DataElement.class);
	  criteriaBuilder.populate(criteria);
	  criteria.add(Expression.eq("deletedIndicator", AdminComponent.DELETED_IND_NO));
	  return criteria.list();
	}
      };

    return (List)getHibernateTemplate().execute(callback);
    
  }

  
}