package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.Property;

import java.util.List;

public interface PropertyDAO {

//   public List findByLongName(String name);

  public List find(Property o);

}