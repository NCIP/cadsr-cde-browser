package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.Context;

import java.util.List;

public interface ContextDAO {

  public List findAll();

  public Context findByName(String name);

}