package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.*;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.ContentObjectDAO;
import gov.nih.nci.ncicb.cadsr.model.*;

public class ContentObjectDAOImpl extends HibernateDaoSupport implements ContentObjectDAO {

  public List find(final ContentObject o) {
    
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  Criteria criteria = session.createCriteria(o.getClass());
	  
	  AdminComponentQueryBuilder.buildCriteria(criteria, o);
	  
	  return criteria.list();
	}
      };
    
    return (List)getHibernateTemplate().execute(callback);
    
  }

  public List getChildren(final String pk) {
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {

	  Query query = session.getNamedQuery("co.findByPK");
	  query.setString(0, pk);
	  
	  ContentObject co = (ContentObject)query.list().get(0);
	  List recs = co.getRelatedObjects();

	  ArrayList result = new ArrayList();
	  
	  for(int i = 0; i<recs.size(); i++) {
	    ContentObjectRelationship cor = (ContentObjectRelationship)recs.get(i);
	    result.add(cor.getChild());
	  }
	  
	  return result;
	}
      };
    
    return (List)getHibernateTemplate().execute(callback);

  }

}