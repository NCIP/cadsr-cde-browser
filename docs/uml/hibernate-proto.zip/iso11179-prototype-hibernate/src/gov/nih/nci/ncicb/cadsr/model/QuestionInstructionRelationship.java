package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="ELEMENT_INSTRUCTION"
 *
 */
public class QuestionInstructionRelationship extends ContentObjectRelationship {

}