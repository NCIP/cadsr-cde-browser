package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="ELEMENT_VALUE"
 *
 */
public class QuestionValidValueRelationship extends ContentObjectRelationship {

}