package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class
 *    table="VALUE_DOMAINS"
 *
 * @hibernate.query name="vd.findByPK" query="from ValueDomain as vd where vd.id = ?"
 *
 * @hibernate.query name="vd.findByNameLike" query="from ValueDomain as vd where preferred_name like ?"
 *
 * @hibernate.query name="vd.findByName" query="from ValueDomain as vd where preferred_name = ?"
 *
 */
public class ValueDomain extends AdminComponent
{
  private String id;

  private String dataType;
  private String highValue;
  private String lowValue;

  private String vdType;

  private List valueDomainPermissibleValues;

  private Representation representation;
  private Qualifier qualifier;

  /**
   * Get the VdId value.
   * @return the VdId value.
   *
   * @hibernate.id
   *           column="VD_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   */
  public String getId() {
    return id;
  }

  /**
   * Get the LowValue value.
   * @return the LowValue value.
   *
   * @hibernate.property
   *    column="LOW_VALUE_NUM"
   *    length="255"
   */
  public String getLowValue() {
    return lowValue;
  }
  
  /**
   * Get the HighValue value.
   * @return the HighValue value.
   *
   * @hibernate.property
   *    column="HIGH_VALUE_NUM"
   *    length="255"
   */
  public String getHighValue() {
    return highValue;
  }

  /**
   * Get the VdType value.
   * @return the VdType value.
   *
   * @hibernate.property
   *    column="VD_TYPE_FLAG"
   *    length="1"
   */
  public String getVdType() {
    return vdType;
  }

  /**
   * Get the ValueDomainPermissibleValues value.
   * @return the ValueDomainPermissibleValues value.
   *
   * @hibernate.bag  
   *            name="valueDomainPermissibleValues"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="VD_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ValueDomainPermissibleValue"
   * 
   */
  public List getValueDomainPermissibleValues() {
    return valueDomainPermissibleValues;
  }

  /**
   * Get the Representation value.
   * @return the Representation value.
   *
   * @hibernate.many-to-one 
   * 		column="REP_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.Representation"
   */
  public Representation getRepresentation() {
    return representation;
  }

  /**
   * Get the Qualifier value.
   * @return the Qualifier value.
   *
   * @hibernate.many-to-one 
   * 		column="QUALIFIER_NAME" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.Qualifier"
   */
  public Qualifier getQualifier() {
    return qualifier;
  }




  /**
   * Set the Qualifier value.
   * @param newQualifier The new Qualifier value.
   */
  public void setQualifier(Qualifier newQualifier) {
    this.qualifier = newQualifier;
  }

  /**
   * Set the Representation value.
   * @param newRepresentation The new Representation value.
   */
  public void setRepresentation(Representation newRepresentation) {
    this.representation = newRepresentation;
  }

  /**
   * Set the ValueDomainPermissibleValues value.
   * @param newValueDomainPermissibleValues The new ValueDomainPermissibleValues value.
   */
  public void setValueDomainPermissibleValues(List newValueDomainPermissibleValues) {
    this.valueDomainPermissibleValues = newValueDomainPermissibleValues;
  }
  
  /**
   * Set the VdType value.
   * @param newVdType The new VdType value.
   */
  public void setVdType(String newVdType) {
    this.vdType = newVdType;
  }

  /**
   * Set the LowValue value.
   * @param newLowValue The new LowValue value.
   */
  public void setLowValue(String newLowValue) {
    this.lowValue = newLowValue;
  }

  /**
   * Set the HighValue value.
   * @param newHighValue The new HighValue value.
   */
  public void setHighValue(String newHighValue) {
    this.highValue = newHighValue;
  }

  /**
   * Set the DataType value.
   * @param newDataType The new DataType value.
   */
  public void setDataType(String newDataType) {
    this.dataType = newDataType;
  }

  public void setId(String newId) {
    this.id = newId;
  }


//    public String getDisplayFormat();
//    public void setDisplayFormat(String dispFormat);

//    public String getUnitOfMeasure();
//    public void setUnitOfMeasure(String uom);

//    public String getMaxLength();
//    public void setMaxLength(String maxLength);

//    public String getMinLength();
//    public void setMinLength(String minLength);

//    public String getCharSet();
//    public void setCharSet(String charSet);

//    public String getDecimalPlace();
//    public void setDecimalPlace(String dp);

//    public String getCDContextName();
//    public String getCDPrefName();
//    public Float getCDVersion();

//    public String getVDType();
//    public void setVDType(String type);
   
   
}