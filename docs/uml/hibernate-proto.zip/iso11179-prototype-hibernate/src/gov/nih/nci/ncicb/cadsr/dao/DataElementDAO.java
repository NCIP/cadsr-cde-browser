package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.DataElement;

import java.util.List;

public interface DataElementDAO extends BaseDAO {

  public List find(DataElement de);

}