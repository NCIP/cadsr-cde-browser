package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="FORM_MODULE"
 *
 */
public class FormModuleRelationship extends ContentObjectRelationship {

}