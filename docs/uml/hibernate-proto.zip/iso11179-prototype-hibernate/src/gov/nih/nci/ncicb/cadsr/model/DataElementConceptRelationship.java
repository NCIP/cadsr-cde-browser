package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class
 *    table="DEC_RECS"
 */
public class DataElementConceptRelationship 
{

  private String id;

  private Audit audit;


  private DataElementConcept parent;
  private DataElementConcept child;


  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="DEC_REC_IDSEQ"
   *           generator-class="native"
   */
  public String getId() {
    return id;
  }
  
  /**
   * Get the Audit value.
   * @return the Audit value.
   *
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }


  /**
   * Get the Parent value.
   * @return the Parent value.
   *
   * @hibernate.many-to-one 
   * 		column="P_DEC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElementConcept"
   * 
   */
  public DataElementConcept getParent() {
    return parent;
  }
  /**
   * Get the Child value.
   * @return the Child value.
   *
   * @hibernate.many-to-one 
   * 		column="C_DEC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElementConcept"
   * 
   */
  public DataElementConcept getChild() {
    return child;
  }

  /**
   * Set the Child value.
   * @param newChild The new Child value.
   */
  public void setChild(DataElementConcept newChild) {
    this.child = newChild;
  }
  

  /**
   * Set the Parent value.
   * @param newParent The new Parent value.
   */
  public void setParent(DataElementConcept newParent) {
    this.parent = newParent;
  }

  


  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

   
}