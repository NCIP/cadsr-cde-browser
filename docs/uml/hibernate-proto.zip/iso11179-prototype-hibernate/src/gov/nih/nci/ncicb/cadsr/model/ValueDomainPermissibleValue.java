package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class
 *    table="VD_PVS"
 */
public class ValueDomainPermissibleValue
{

  private String id;

  private Audit audit;

  private ValueDomain valueDomain;
  private PermissibleValue permissibleValue;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="VP_IDSEQ"
   *           generator-class="native"
   */
  public String getId() {
    return id;
  }
  
  /**
   * Get the ValueDomain value.
   * @return the ValueDomain value.
   *
   * @hibernate.many-to-one 
   * 		column="VD_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ValueDomain"
   * 
   * 
   */
  public ValueDomain getValueDomain() {
    return valueDomain;
  }
  
  /**
   * Get the Audit value.
   * @return the Audit value.
   *
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }

  /**
   * Get the PermissibleValue value.
   * @return the PermissibleValue value.
   *
   * @hibernate.many-to-one 
   * 		column="PV_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.PermissibleValue"
   * 
   */
  public PermissibleValue getPermissibleValue() {
    return permissibleValue;
  }



  /**
   * Set the PermissibleValue value.
   * @param newPermissibleValue The new PermissibleValue value.
   */
  public void setPermissibleValue(PermissibleValue newPermissibleValue) {
    this.permissibleValue = newPermissibleValue;
  }

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  /**
   * Set the ValueDomain value.
   * @param newValueDomain The new ValueDomain value.
   */
  public void setValueDomain(ValueDomain newValueDomain) {
    this.valueDomain = newValueDomain;
  }
   
}