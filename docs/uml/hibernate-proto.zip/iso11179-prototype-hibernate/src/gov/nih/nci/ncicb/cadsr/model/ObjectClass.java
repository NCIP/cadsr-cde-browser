package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.class
 *           table="OBJECT_CLASSES_EXT"
 */
public class ObjectClass extends AdminComponent {

  private String ocId;
  private String definitionSource;

  /**
   * Get the OcId value.
   * @return the OcId value.
   *
   * @hibernate.id
   *           column="OC_IDSEQ"
   *           generator-class="native"
   * 
   */
  public String getOcId() {
    return ocId;
  }



  /**
   * Get the DefinitionSource value.
   * @return the DefinitionSource value.
   *
   * @hibernate.property
   *    column="DEFINITION_SOURCE"
   *    type="string"
   *    length="2000"
   */
  public String getDefinitionSource() {
    return definitionSource;
  }


  /**
   * Set the DefinitionSource value.
   * @param newDefinitionSource The new DefinitionSource value.
   */
  public void setDefinitionSource(String newDefinitionSource) {
    this.definitionSource = newDefinitionSource;
  }

  

  /**
   * Set the OcId value.
   * @param newOcId The new OcId value.
   */
  public void setOcId(String newOcId) {
    this.ocId = newOcId;
  }

  

}
