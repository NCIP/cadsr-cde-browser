package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.class
 *           table="OBJECT_CLASSES_EXT"
 */
public class ObjectClass extends AdminComponent {

  private String id;
  private String definitionSource;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="OC_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   * 
   */
  public String getId() {
    return id;
  }



  /**
   * Get the DefinitionSource value.
   * @return the DefinitionSource value.
   *
   * @hibernate.property
   *    column="DEFINITION_SOURCE"
   *    type="string"
   *    length="2000"
   */
  public String getDefinitionSource() {
    return definitionSource;
  }


  /**
   * Set the DefinitionSource value.
   * @param newDefinitionSource The new DefinitionSource value.
   */
  public void setDefinitionSource(String newDefinitionSource) {
    this.definitionSource = newDefinitionSource;
  }

  

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

  

}
