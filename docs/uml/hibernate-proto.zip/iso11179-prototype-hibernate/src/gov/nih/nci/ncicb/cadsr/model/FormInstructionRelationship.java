package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="FORM_INSTRUCTION"
 *
 */
public class FormInstructionRelationship extends ContentObjectRelationship {

}