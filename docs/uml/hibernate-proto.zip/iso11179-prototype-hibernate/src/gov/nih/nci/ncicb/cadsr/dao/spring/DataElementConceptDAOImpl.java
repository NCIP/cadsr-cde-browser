package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.DataElementConceptDAO;
import gov.nih.nci.ncicb.cadsr.model.DataElementConcept;
import gov.nih.nci.ncicb.cadsr.model.ObjectClass;
import gov.nih.nci.ncicb.cadsr.model.Property;

public class DataElementConceptDAOImpl extends HibernateDaoSupport implements DataElementConceptDAO {

  public List find(final DataElementConcept o) {
    
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	    
	  Criteria criteria = session.createCriteria(DataElementConcept.class);

	  AdminComponentQueryBuilder.buildCriteria(criteria, o);
	  
	  ObjectClass oc = o.getObjectClass();
	  Property prop = o.getProperty();

	  if(oc != null) {
	    if(oc.getLongName() != null) {
	      criteria.add(Expression.like("objectClass.longName", oc.getLongName()));
	    }
	  }

	  if(prop != null) {
	    if(prop.getLongName() != null) {
	      criteria.add(Expression.like("property.longName", prop.getLongName()));
	    }
	  }

	  return criteria.list();
	}
      };

    return (List)getHibernateTemplate().execute(callback);
    
  }

}