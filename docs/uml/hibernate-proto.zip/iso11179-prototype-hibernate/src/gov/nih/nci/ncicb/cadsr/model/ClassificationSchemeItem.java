package gov.nih.nci.ncicb.cadsr.model;


/**
 * @hibernate.class table="CLASS_SCHEME_ITEMS"
 * 
 */
public class ClassificationSchemeItem 
{

  private String csiId;
  private String type;
  private Audit audit;
  private String name;
  private String description;
  private String comment;

  /**
   * Get the CsiId value.
   * @return the CsiId value.
   *
   * @hibernate.id
   *      column="CSI_IDSEQ"
   *      generator-class="native"
   * 
   */
  public String getCsiId() {
    return csiId;
  }


  /**
   * Get the Type value.
   * @return the Type value.
   * 
   * @hibernate.property
   *            column="CSITL_NAME"
   *            type="string"
   *            length="20"
   */
  public String getType() {
    return type;
  }


  /**
   * Get the Name value.
   * @return the Name value.
   * 
   * @hibernate.property
   *            column="CSI_NAME"
   *            type="string"
   *            length="20"
   */
  public String getName() {
    return name;
  }


  /**
   * Get the Description value.
   * @return the Description value.
   * 
   * @hibernate.property
   *            column="DESCRIPTION"
   *            type="string"
   *            length="60"
   */
  public String getDescription() {
    return description;
  }


  /**
   * Get the Comment value.
   * @return the Comment value.
   * 
   * @hibernate.property
   *            column="COMMENTS"
   *            type="string"
   *            length="2000"
   */
  public String getComment() {
    return comment;
  }

  /**
   * Set the Comment value.
   * @param newComment The new Comment value.
   */
  public void setComment(String newComment) {
    this.comment = newComment;
  }

  

  /**
   * Set the Description value.
   * @param newDescription The new Description value.
   */
  public void setDescription(String newDescription) {
    this.description = newDescription;
  }

  

  /**
   * Set the Name value.
   * @param newName The new Name value.
   */
  public void setName(String newName) {
    this.name = newName;
  }

  


  /**
   * Get the Audit value.
   * @return the Audit value.
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  

  /**
   * Set the Type value.
   * @param newType The new Type value.
   */
  public void setType(String newType) {
    this.type = newType;
  }

  /**
   * Set the CsiId value.
   * @param newCsiId The new CsiId value.
   */
  public void setCsiId(String newCsiId) {
    this.csiId = newCsiId;
  }

  

}