package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.PropertyDAO;
import gov.nih.nci.ncicb.cadsr.model.Property;

public class PropertyDAOImpl extends HibernateDaoSupport implements PropertyDAO {

  public List find(final Property o) {
    
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  Criteria criteria = session.createCriteria(Property.class);
	  
	  AdminComponentQueryBuilder.buildCriteria(criteria, o);
	  
	  return criteria.list();
	}
      };
    
    return (List)getHibernateTemplate().execute(callback);
    
  }

}