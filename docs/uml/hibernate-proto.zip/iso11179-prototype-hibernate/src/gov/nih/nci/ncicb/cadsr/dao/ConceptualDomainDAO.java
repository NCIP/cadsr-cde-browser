package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.ConceptualDomain;

import java.util.List;

public interface ConceptualDomainDAO {

  public List find(ConceptualDomain vd);

}