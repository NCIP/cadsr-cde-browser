package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.class 
 *      table="QC_RECS_EXT"
 *
 * @hibernate.discriminator column="RL_NAME"
 * 
 */
public class ContentObjectRelationship  {

  private String id;
  private Audit audit;

  private ContentObject child;
  private ContentObject parent;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *    column="QR_IDSEQ"
   *    generator-class="native"
   */
  public String getId() {
    return id;
  }

  /**
   * Get the Audit value.
   * @return the Audit value.
   *
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }


  /**
   * Get the Parent value.
   * @return the Parent value.
   *
   * @hibernate.many-to-one 
   * 		column="P_QC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ContentObject"
   * 
   */
  public ContentObject getParent() {
    return parent;
  }

  /**
   * Get the Child value.
   * @return the Child value.
   *
   * @hibernate.many-to-one 
   * 		column="C_QC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ContentObject"
   * 
   */
  public ContentObject getChild() {
    return child;
  }




  /**
   * Set the Child value.
   * @param newChild The new Child value.
   */
  public void setChild(ContentObject newChild) {
    this.child = newChild;
  }

  /**
   * Set the Parent value.
   * @param newParent The new Parent value.
   */
  public void setParent(ContentObject newParent) {
    this.parent = newParent;
  }

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  public void setId(String newId) {
    this.id = newId;
  }

  

}