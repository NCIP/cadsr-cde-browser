package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.class
 *           table="DATA_ELEMENTS"
 * 
 *
 * @hibernate.query name="de.findByPK" query="from DataElement as de where de.id = ?"
 *
 */
public class DataElement extends AdminComponent{

  private String id;
  private ValueDomain valueDomain;
  private DataElementConcept dataElementConcept;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="DE_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   */
  public String getId() {
    return id;
  }

  /**
   * Get the DataElementConcept value.
   * @return the DataElementConcept value.
   *
   * @hibernate.many-to-one 
   * 		column="DEC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElementConcept"
   * 
   */
  public DataElementConcept getDataElementConcept() {
    return dataElementConcept;
  }

  /**
   * Get the ValueDomain value.
   * @return the ValueDomain value.
   *
   * @hibernate.many-to-one 
   * 		column="VD_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ValueDomain"
   */
  public ValueDomain getValueDomain() {
    return valueDomain;
  }


  /**
   * Set the DataElementConcept value.
   * @param newDataElementConcept The new DataElementConcept value.
   */
  public void setDataElementConcept(DataElementConcept newDataElementConcept) {
    this.dataElementConcept = newDataElementConcept;
  }

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

  /**
   * Set the ValueDomain value.
   * @param newValueDomain The new ValueDomain value.
   */
  public void setValueDomain(ValueDomain newValueDomain) {
    this.valueDomain = newValueDomain;
  }


//   public String getCDEId();
//   public String getDecName();
  
//   public void setLongCDEName (String pLongCDEName);
//   public void setContextName(String pConteName);
//   public void setCDEId(String pCDEId);
  
//   public String getUsingContexts();
//   public void setUsingContexts(String usingContexts);
  
}
