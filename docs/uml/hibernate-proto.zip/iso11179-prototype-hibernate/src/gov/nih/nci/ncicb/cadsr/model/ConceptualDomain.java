package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class
 *    table="CONCEPTUAL_DOMAINS"
 *
 */
public class ConceptualDomain extends AdminComponent
{

  private String id;
  private String dimensionality;
  private List conceptualDomainValueMeanings;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="CD_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   */
  public String getId() {
    return id;
  }


  /**
   * Get the Dimensionality value.
   * @return the Dimensionality value.
   *
   * @hibernate.property
   *    column="DIMENSIONALITY"
   *    length="30"
   */
  public String getDimensionality() {
    return dimensionality;
  }


  /**
   * Get the ConceptualDomainValueMeanings value.
   * @return the ConceptualDomainValueMeanings value.
   *
   * @hibernate.bag  
   *            name="conceptualDomainValueMeanings"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="CD_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ConceptualDomainValueMeaning"
   * 
   */
  public List getConceptualDomainValueMeanings() {
    return conceptualDomainValueMeanings;
  }

  /**
   * Set the ConceptualDomainValueMeanings value.
   * @param newConceptualDomainValueMeanings The new ConceptualDomainValueMeanings value.
   */
  public void setConceptualDomainValueMeanings(List newConceptualDomainValueMeanings) {
    this.conceptualDomainValueMeanings = newConceptualDomainValueMeanings;
  }

  

  /**
   * Set the Dimensionality value.
   * @param newDimensionality The new Dimensionality value.
   */
  public void setDimensionality(String newDimensionality) {
    this.dimensionality = newDimensionality;
  }

  

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

  

}