package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import net.sf.hibernate.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.ConceptualDomainDAO;
import gov.nih.nci.ncicb.cadsr.model.*;

public class ConceptualDomainDAOImpl extends HibernateDaoSupport implements ConceptualDomainDAO {


  public List find(final ConceptualDomain o) {
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  Criteria criteria = session.createCriteria(o.getClass());

	  AdminComponentQueryBuilder.buildCriteria(criteria, o);

	  return criteria.list();
	}
      };

    return (List)getHibernateTemplate().execute(callback);

  }

}