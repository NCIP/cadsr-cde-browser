package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.subclass 
 *            discriminator-value="CRF"
 * 
 */
public class CaseReportForm extends ContentObject {



}