package gov.nih.nci.ncicb.cadsr.hibernate;

import java.io.Serializable;

import net.sf.hibernate.id.IdentifierGenerator;
import net.sf.hibernate.engine.SessionImplementor;

import java.sql.CallableStatement;

public class AcIdGenerator implements IdentifierGenerator {
  
  public Serializable generate(SessionImplementor session, Object object) {

    try {
      CallableStatement stmt = session.connection().prepareCall("{? = call ADMINCOMPONENT_CRUD.CMR_GUID() }");
      stmt.registerOutParameter(1, java.sql.Types.VARCHAR);
      stmt.execute();
      
      String id =  stmt.getString(1);
      stmt.close();
      
      return id;
    } catch (Exception e){
      return null;
    } // end of try-catch
  }
  
}