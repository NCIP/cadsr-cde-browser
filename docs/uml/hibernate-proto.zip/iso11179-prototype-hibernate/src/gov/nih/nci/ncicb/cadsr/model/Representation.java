package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.class 
 *      table="REPRESENTATIONS_EXT"
 */
public class Representation extends AdminComponent {

  String id;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="REP_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   */
  public String getId() {
    return id;
  }

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

  
  

}