package gov.nih.nci.ncicb.cadsr.model;

import java.util.Date;

public class Audit {

  private Date creationDate;
  private Date modificationDate;

  private String createdBy;
  private String modifiedBy;


  /**
   * Get the CreationDate value.
   * @return the CreationDate value.
   *
   * @hibernate.property
   *     column="DATE_CREATED"
   *     type="java.util.Date"
   *     not-null="false"
   */
  public Date getCreationDate() {
    return creationDate;
  }

  /**
   * Get the ModifiedBy value.
   * @return the ModifiedBy value.
   *
   * @hibernate.property
   *     column="MODIFIED_BY"
   *     type="string"
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  /**
   * Get the CreatedBy value.
   * @return the CreatedBy value.
   *
   * @hibernate.property
   *     column="CREATED_BY"
   *     type="string"
   */
  public String getCreatedBy() {
    return createdBy;
  }


  /**
   * Get the ModificationDate value.
   * @return the ModificationDate value.
   *
   * @hibernate.property
   *     column="DATE_MODIFIED"
   *     type="date"
   *     not-null="false"
   */
  public Date getModificationDate() {
    return modificationDate;
  }

  /**
   * Set the ModifiedBy value.
   * @param newModifiedBy The new ModifiedBy value.
   */
  public void setModifiedBy(String newModifiedBy) {
    this.modifiedBy = newModifiedBy;
  }


  /**
   * Set the CreatedBy value.
   * @param newCreatedBy The new CreatedBy value.
   */
  public void setCreatedBy(String newCreatedBy) {
    this.createdBy = newCreatedBy;
  }

  

  /**
   * Set the ModificationDate value.
   * @param newModificationDate The new ModificationDate value.
   */
  public void setModificationDate(Date newModificationDate) {
    this.modificationDate = newModificationDate;
  }

  

  /**
   * Set the CreationDate value.
   * @param newCreationDate The new CreationDate value.
   */
  public void setCreationDate(Date newCreationDate) {
    this.creationDate = newCreationDate;
  }


}  
