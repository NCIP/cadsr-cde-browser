package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.ClassificationSchemeDAO;
import gov.nih.nci.ncicb.cadsr.model.ClassificationScheme;
import gov.nih.nci.ncicb.cadsr.model.ClassSchemeClassSchemeItem;
import gov.nih.nci.ncicb.cadsr.model.ObjectClass;
import gov.nih.nci.ncicb.cadsr.model.Property;

public class ClassificationSchemeDAOImpl extends HibernateDaoSupport implements ClassificationSchemeDAO {

  public List find(final ClassificationScheme o) {
    
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	    
	  Criteria criteria = session.createCriteria(ClassificationScheme.class);

	  System.out.println("BUILDING QUERY...");
	  AdminComponentQueryBuilder.buildCriteria(criteria, o);
	  
	  return criteria.list();
	}
      };

    return (List)getHibernateTemplate().execute(callback);
    
  }

  public List getCsis(final String pk ) {
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  Query query = session.getNamedQuery("cs.findByPK");
	  query.setString(0, pk);

	  ClassificationScheme cs = (ClassificationScheme)query.list().get(0);
	  List csCsi = cs.getCsCsis();

	  List result = new ArrayList();
	  for(int i=0; i<csCsi.size(); i++) {
	    result.add(((ClassSchemeClassSchemeItem)csCsi.get(i)).getCsi());
	  }
	  
	  return result;
	}
	
      };
      
    return (List)getHibernateTemplate().execute(callback);

  }

}