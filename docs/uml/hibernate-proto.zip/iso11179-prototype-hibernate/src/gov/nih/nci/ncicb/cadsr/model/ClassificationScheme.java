package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class table="CLASSIFICATION_SCHEMES"
 * 
 * @hibernate.query 
 *            name="cs.findByPK"
 *            query="from ClassificationScheme as cs where cs.id = ?"
 */
public class ClassificationScheme extends AdminComponent
{

  private String id;
  private String type;
  private List csCsis;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="CS_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   * 
   */
  public String getId() {
    return id;
  }


  /**
   * Get the Type value.
   * @return the Type value.
   * 
   * @hibernate.property
   *            column="CSTL_NAME"
   *            type="string"
   *            length="20"
   */
  public String getType() {
    return type;
  }


  /**
   * Get the CsCsis value.
   * @return the CsCsis value.
   *
   * @hibernate.bag  
   *            name="csCsis"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="CS_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ClassSchemeClassSchemeItem"
   * 
   */
  public List getCsCsis() {
    return csCsis;
  }

  /**
   * Set the CsCsis value.
   * @param newCsCsis The new CsCsis value.
   */
  public void setCsCsis(List newCsCsis) {
    this.csCsis = newCsCsis;
  }

  

  /**
   * Set the Type value.
   * @param newType The new Type value.
   */
  public void setType(String newType) {
    this.type = newType;
  }

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

  

}