package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.subclass 
 *            discriminator-value="MODULE_INSTR"
 * 
 */
public class ModuleInstruction extends ContentObject {



}