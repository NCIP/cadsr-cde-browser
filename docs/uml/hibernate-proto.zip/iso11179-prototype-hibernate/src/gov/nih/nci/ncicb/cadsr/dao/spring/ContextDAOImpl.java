package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.ContextDAO;
import gov.nih.nci.ncicb.cadsr.model.Context;

public class ContextDAOImpl extends HibernateDaoSupport implements ContextDAO {

  public List findAll(){
    return getHibernateTemplate().findByNamedQuery("context.findAll");
  }

  public Context findByName(String name) {
    try {
      return (Context)getHibernateTemplate().findByNamedQuery("context.findByName", name).get(0);
    } catch (Throwable t){
      return null;
    } // end of try-catch
  }

}