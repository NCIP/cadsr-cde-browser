package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class
 *    table="VD_PVS"
 */
public class ConceptualDomainValueMeaning
{

  private String cdVmId;

  private Audit audit;

  private ConceptualDomain conceptualDomain;
  private ValueMeaning valueMeaning;

  /**
   * Get the cdVmId value.
   * @return the cdVmId value.
   *
   * @hibernate.id
   *           column="CV_IDSEQ"
   *           generator-class="native"
   */
  public String getCdVmId() {
    return cdVmId;
  }
  
  /**
   * Get the ConceptualDomain value.
   * @return the ConceptualDomain value.
   *
   * @hibernate.many-to-one 
   * 		column="CD_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ConceptualDomain"
   * 
   * 
   */
  public ConceptualDomain getConceptualDomain() {
    return conceptualDomain;
  }
  
  /**
   * Get the Audit value.
   * @return the Audit value.
   *
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }

  /**
   * Get the ValueMeaning value.
   * @return the ValueMeaning value.
   *
   * @hibernate.many-to-one 
   * 		column="SHORT_MEANING" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ValueMeaning"
   * 
   */
  public ValueMeaning getValueMeaning() {
    return valueMeaning;
  }



  /**
   * Set the ValueMeaning value.
   * @param newValueMeaning The new ValueMeaning value.
   */
  public void setValueMeaning(ValueMeaning newValueMeaning) {
    this.valueMeaning = newValueMeaning;
  }

  /**
   * Set the VdPvId value.
   * @param newVdPvId The new VdPvId value.
   */
  public void setCdVmId(String newCdVmId) {
    this.cdVmId = newCdVmId;
  }

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  /**
   * Set the ConceptualDomain value.
   * @param newConceptualDomain The new ConceptualDomain value.
   */
  public void setConceptualDomain(ConceptualDomain newConceptualDomain) {
    this.conceptualDomain = newConceptualDomain;
  }
   
}