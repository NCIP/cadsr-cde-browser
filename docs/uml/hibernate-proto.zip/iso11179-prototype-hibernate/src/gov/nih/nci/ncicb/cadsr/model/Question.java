package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="QUESTION"
 * 
 */
public class Question extends ContentObject {

  private DataElement dataElement;

  /**
   * Get the DataElement value.
   * @return the DataElement value.
   *
   *
   * @hibernate.many-to-one 
   * 		column="DE_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElement"
   * 
   */
  public DataElement getDataElement() {
    return dataElement;
  }

  /**
   * Set the DataElement value.
   * @param newDataElement The new DataElement value.
   */
  public void setDataElement(DataElement newDataElement) {
    this.dataElement = newDataElement;
  }

  

}