package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="ELEMENT_MODULE"
 *
 */
public class QuestionModuleRelationship extends ContentObjectRelationship {

}