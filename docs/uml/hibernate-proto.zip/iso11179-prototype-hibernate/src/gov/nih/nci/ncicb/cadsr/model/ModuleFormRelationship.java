package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="MODULE_FORM"
 *
 */
public class ModuleFormRelationship extends ContentObjectRelationship {

}