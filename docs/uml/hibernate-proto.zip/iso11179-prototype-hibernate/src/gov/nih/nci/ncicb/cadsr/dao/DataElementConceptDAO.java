package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.DataElementConcept;

import java.util.List;

public interface DataElementConceptDAO {

  public List find(DataElementConcept de);

}