package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.class 
 *      table="REFERENCE_DOCUMENTS"
 */
public class ReferenceDocument {

  private String id;

  private Audit audit;
  private String text;

  /**
   * Get the Name value.
   * @return the Name value.
   *
   * @hibernate.id
   *    column="RD_IDSEQ"
   *    generator-class="native"
   */
  public String getId() {
    return id;
  }

  /**
   * Get the Audit value.
   * @return the Audit value.
   *
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }

  /**
   * Get the Text value.
   * @return the Text value.
   * 
   * @hibernate.property
   *    column="DOC_TEXT"
   *    type="string"
   *    length="200"
   */
  public String getText() {
    return text;
  }





  /**
   * Set the Text value.
   * @param newText The new Text value.
   */
  public void setText(String newText) {
    this.text = newText;
  }

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

}