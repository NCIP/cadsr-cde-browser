package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.class table="CS_CSI"
 * 
 */
public class AdminComponentClassSchemeClassSchemeItem {

  private String acCsCsiId;
  private Audit audit;

  private ClassSchemeClassSchemeItem csCsi;

  /**
   * Get the CsCsiId value.
   * @return the CsCsiId value.
   *
   * @hibernate.id
   *      column="AC_CSI_IDSEQ"
   *      generator-class="native"
   * 
   */
  public String getAcCsCsiId() {
    return acCsCsiId;
  }



  /**
   * Get the Audit value.
   * @return the Audit value.
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }


  /**
   * Get the CsCsi value.
   * @return the CsCsi value.
   *
   * @hibernate.many-to-one 
   * 		column="CS_CSI_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ClassSchemeClassSchemeItem"
   * 
   */
  public ClassSchemeClassSchemeItem getCsCsi() {
    return csCsi;
  }

  

  /**
   * Set the Csi value.
   * @param newCsi The new Csi value.
   */
  public void setCsCsi(ClassSchemeClassSchemeItem newCsCsi) {
    this.csCsi = newCsCsi;
  }


  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  

  /**
   * Set the CsCsiId value.
   * @param newCsCsiId The new CsCsiId value.
   */
  public void setAcCsCsiId(String newAcCsCsiId) {
    this.acCsCsiId = newAcCsCsiId;
  }

  

}