package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.ContentObject;

import java.util.List;

public interface ContentObjectDAO {

  public List find(ContentObject o);

  public List getChildren(String pk);

}