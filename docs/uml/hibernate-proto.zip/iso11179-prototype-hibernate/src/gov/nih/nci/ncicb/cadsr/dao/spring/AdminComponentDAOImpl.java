package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.*;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.AdminComponentDAO;
import gov.nih.nci.ncicb.cadsr.model.*;

public class AdminComponentDAOImpl extends HibernateDaoSupport implements AdminComponentDAO {

  static final HashMap qMap = new HashMap();
  static {
    qMap.put("gov.nih.nci.ncicb.cadsr.model.ClassificationScheme", "cs");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.ConceptualDomain", "cd");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.Context", "context");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.DataElement", "de"); 
    qMap.put("gov.nih.nci.ncicb.cadsr.model.DataElementConcept", "dec");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.Designation", "des");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.ObjectClass", "oc");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.PermissibleValue", "pv");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.Property", "prop");
    qMap.put("gov.nih.nci.ncicb.cadsr.model.ValueDomain", "vd");
 }


  public List getClassificationSchemes(final AdminComponent ac ) {
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  String pre = (String)qMap.get(ac.getClass().getName());

	  Query query = session.getNamedQuery(pre + ".findByPK");
	  query.setString(0, ac.getId());

	  // list of acCsCsi
	  List list = query.list();
	  List result = new ArrayList();

	  AdminComponent ac2 = (AdminComponent)list.get(0);

	  List acCsCsis = ac2.getAcCsCsis();

	  for(int i=0; i<acCsCsis.size(); i++) {
	    AdminComponentClassSchemeClassSchemeItem acCsCsi = (AdminComponentClassSchemeClassSchemeItem)acCsCsis.get(i);

	    ClassSchemeClassSchemeItem csCsi = acCsCsi.getCsCsi();

	    result.add(csCsi.getCs());
	  }
	  
	  return result;
	}
	
      };
      
    return (List)getHibernateTemplate().execute(callback);

  }

}