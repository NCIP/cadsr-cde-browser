package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.*;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.AdminComponentDAO;
import gov.nih.nci.ncicb.cadsr.model.*;

public class AdminComponentDAOImpl extends HibernateDaoSupport implements AdminComponentDAO {

  static {
    HashMap qMap = new HashMap();
    qMap.put("ClassificationScheme", "cs");
    qMap.put("ClassificationSchemeItem", "csi");
    qMap.put("ConceptualDomain", "cd");
    qMap.put("Context", "context");
    qMap.put("DataElement", "de"); 
    qMap.put("DataElementConcept", "dec");
    qMap.put("Designation", "des");
    qMap.put("ObjectClass", "oc");
    qMap.put("PermissibleValue", "pv");
    qMap.put("Property", "prop");
    qMap.put("ValueDomain", "vd");
 }


  public List getClassificationScheme(final AdminComponent ac ) {
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  System.out.println("%%%%%%%%%%%%%%% AC CLASS: " + ac.getClass().getName());
	  
	  String pre = qMap.get(ac.getClass().getName());

	  Query query = session.getNamedQuery(pre + ".findByPK");
	  // !!!!! ZUT
	  query.setString(0, "000000");

	  // list of acCsCsi
	  List list = query.list();
	  List result = new ArrayList();

	  ac = (AdminComponent)list.get(0);

	  List acCsCsis = ac.getAcCsCsis();

	  for(int i=0; i<acCsCsis.size(); i++) {
	    AdminComponentClassShemeClassShemeItem acCsCsi = acCsCsis.get(i);

	    ClassSchemeClassSchemeItem csCsi = acCsCsi.getCsCsi();

	    result.add(csCsi.getClassificationScheme());
	  }
	  
	  return result;
	}
	
      };
      
    return (List)getHibernateTemplate().execute(callback);

  }

}