package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

public class AdminComponent {
  
  private String workflowStatus;
  private Context context;
  private String preferredDefinition;
  private Float version;
  private String longName;
  private String preferredName;

  private Audit audit;
  private Lifecycle lifecycle;

  private String origin;
  private String changeNote;
  private List designations;

  private List acCsCsis;

  
  /**
   * Get the PreferredName value.
   * @return the PreferredName value.
   *
   * @hibernate.property
   *          column="PREFERRED_NAME"
   *          length="30"
   */
  public String getPreferredName() {
    return preferredName;
  }

  /**
   * Get the LongName value.
   * @return the LongName value.
   *
   * @hibernate.property
   *          column="LONG_NAME"
   *          length="255"
   */
  public String getLongName() {
    return longName;
  }


  /**
   * Get the Version value.
   * @return the Version value.
   *
   * @hibernate.property
   *          column="VERSION"
   */
  public Float getVersion() {
    return version;
  }

  

  /**
   * Get the PreferredDefinition value.
   * @return the PreferredDefinition value.
   *
   * @hibernate.property
   *          column="PREFERRED_DEFINITION"
   */
  public String getPreferredDefinition() {
    return preferredDefinition;
  }

  /**
   * Get the Context value.
   * @return the Context value.
   *
   *
   * @hibernate.many-to-one 
   * 		column="CONTE_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.Context"
   */
  public Context getContext() {
    return context;
  }

  /**
   * Get the WorkflowStatus value.
   * @return the WorkflowStatus value.
   *
   * @hibernate.property
   *          column="ASL_NAME"
              length="20"
   */
  public String getWorkflowStatus() {
    return workflowStatus;
  }


  /**
   * Get the Audit value.
   * @return the Audit value.
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }


  /**
   * Get the Lifecycle value.
   * @return the Lifecycle value.
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Lifecycle"
   */
  public Lifecycle getLifecycle() {
    return lifecycle;
  }

  /**
   * Get the ChangeNote value.
   * @return the ChangeNote value.
   *
   * @hibernate.property
   *          column="CHANGE_NOTE"
   *          length="2000"
   */
  public String getChangeNote() {
    return changeNote;
  }

  /**
   * Get the Origin value.
   * @return the Origin value.
   *
   * @hibernate.property
   *          column="ORIGIN"
   *          length="240"
   */
  public String getOrigin() {
    return origin;
  }


  /**
   * Get the Designations value.
   * @return the Designations value.   
   * 
   * @hibernate.bag  
   *            name="designations"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="PV_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.Designation"
   * 
   */
  public List getDesignations() {
    return designations;
  }

  /**
   * Get the AcCsCsis value.
   * @return the AcCsCsis value.
   * 
   * @hibernate.bag  
   *            name="acCsCsis"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="AC_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.AdminComponentClassSchemeClassSchemeItem"
   * 
   */
  public List getAcCsCsis() {
    return acCsCsis;
  }





  /**
   * Set the AcCsCsis value.
   * @param newAcCsCsis The new AcCsCsis value.
   */
  public void setAcCsCsis(List newAcCsCsis) {
    this.acCsCsis = newAcCsCsis;
  }

  /**
   * Set the Designations value.
   * @param newDesignations The new Designations value.
   */
  public void setDesignations(List newDesignations) {
    this.designations = newDesignations;
  }

  

  /**
   * Set the Lifecycle value.
   * @param newLifecycle The new Lifecycle value.
   */
  public void setLifecycle(Lifecycle newLifecycle) {
    this.lifecycle = newLifecycle;
  }

  

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }


  /**
   * Set the PreferredDefinition value.
   * @param newPreferredDefinition The new PreferredDefinition value.
   */
  public void setPreferredDefinition(String newPreferredDefinition) {
    this.preferredDefinition = newPreferredDefinition;
  }

  /**
   * Set the Context value.
   * @param newContext The new Context value.
   */
  public void setContext(Context newContext) {
    this.context = newContext;
  }

  /**
   * Set the Version value.
   * @param newVersion The new Version value.
   */
  public void setVersion(Float newVersion) {
    this.version = newVersion;
  }

  /**
   * Set the WorkflowStatus value.
   * @param newWorkflowStatus The new WorkflowStatus value.
   */
  public void setWorkflowStatus(String newWorkflowStatus) {
    this.workflowStatus = newWorkflowStatus;
  }
  /**
   * Set the LongName value.
   * @param newLongName The new LongName value.
   */
  public void setLongName(String newLongName) {
    this.longName = newLongName;
  }
  /**
   * Set the PreferredName value.
   * @param newPreferredName The new PreferredName value.
   */
  public void setPreferredName(String newPreferredName) {
    this.preferredName = newPreferredName;
  }

  /**
   * Set the ChangeNote value.
   * @param newChangeNote The new ChangeNote value.
   */
  public void setChangeNote(String newChangeNote) {
    this.changeNote = newChangeNote;
  }


  /**
   * Set the Origin value.
   * @param newOrigin The new Origin value.
   */
  public void setOrigin(String newOrigin) {
    this.origin = newOrigin;
  }

  


  

}
