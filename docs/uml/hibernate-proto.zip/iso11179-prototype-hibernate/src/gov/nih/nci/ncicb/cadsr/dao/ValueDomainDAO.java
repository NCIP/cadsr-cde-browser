package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.ValueDomain;

import java.util.List;

public interface ValueDomainDAO {

  public List findByNameLike(String name);

  public ValueDomain findByName(String name);

  public List getPermissibleValues(String pk);

}