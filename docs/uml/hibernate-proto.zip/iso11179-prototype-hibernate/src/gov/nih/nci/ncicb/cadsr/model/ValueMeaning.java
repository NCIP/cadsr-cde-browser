package gov.nih.nci.ncicb.cadsr.model;

import java.util.Date;

/**
 * @hibernate.class
 *    table="VALUE_MEANINGS_LOV"
 */
public class ValueMeaning {

  private String shortMeaning;

  private String description;
  private String comments;

  private Audit audit;
  private Lifecycle lifecycle;

  /**
   * Get the ShortMeaning value.
   * @return the ShortMeaning value.
   * 
   * @hibernate.id
   *    column="SHORT_MEANING"
   *    generator-class="native"
   */
  public String getShortMeaning() {
    return shortMeaning;
  }


  /**
   * Get the Lifecycle value.
   * @return the Lifecycle value.
   *
   * @hibernate.component
   */
  public Lifecycle getLifecycle() {
    return lifecycle;
  }

  /**
   * Get the Audit value.
   * @return the Audit value.
   *
   * @hibernate.component
   */
  public Audit getAudit() {
    return audit;
  }


  /**
   * Get the Comments value.
   * @return the Comments value.
   * 
   * @hibernate.property
   *    column="COMMENTS"
   *    type="string"
   *    length="2000"
   */
  public String getComments() {
    return comments;
  }

  /**
   * Get the Description value.
   * @return the Description value.
   * 
   * @hibernate.property
   *    column="DESCRIPTION"
   *    type="string"
   *    length="2000"
   */
  public String getDescription() {
    return description;
  }

  /**
   * Set the Lifecycle value.
   * @param newLifecycle The new Lifecycle value.
   */
  public void setLifecycle(Lifecycle newLifecycle) {
    this.lifecycle = newLifecycle;
  }

  /**
   * Set the Description value.
   * @param newDescription The new Description value.
   */
  public void setDescription(String newDescription) {
    this.description = newDescription;
  }

  /**
   * Set the ShortMeaning value.
   * @param newShortMeaning The new ShortMeaning value.
   */
  public void setShortMeaning(String newShortMeaning) {
    this.shortMeaning = newShortMeaning;
  }


  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  /**
   * Set the Comments value.
   * @param newComments The new Comments value.
   */
  public void setComments(String newComments) {
    this.comments = newComments;
  }

}