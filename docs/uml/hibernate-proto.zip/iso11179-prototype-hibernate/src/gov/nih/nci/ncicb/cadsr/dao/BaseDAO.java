package gov.nih.nci.ncicb.cadsr.dao;

import java.util.List;

public interface BaseDAO {

  public List findByCriteria(CriteriaBuilder cb);

}