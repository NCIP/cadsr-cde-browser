package gov.nih.nci.ncicb.cadsr.model;


/**
 * @hibernate.class table="CONTEXTS"
 * 
 * 
 * @hibernate.query name="context.findAll" query="from Context as c"
 * 
 * @hibernate.query name="context.findByName" query="from Context as c where c.name = ?"
 * 
 */
public class Context
{

  private String id;
  private String name;
  private Audit audit;


  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *      column="CONTE_IDSEQ"
   *      generator-class="native"
   * 
   */
  public String getId() {
    return id;
  }

  /**
   * Get the Audit value.
   * @return the Audit value.
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }

  /**
   * Get the Name value.
   * @return the Name value.
   *
   * @hibernate.property 
   * 		column="name"
   * 		type="string"
   * 		length="30"   
   */
  public String getName() {
    return name;
  }

  

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }


  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  /**
   * Set the Name value.
   * @param newName The new Name value.
   */
  public void setName(String newName) {
    this.name = newName;
  }



//   public String getLlName();
//   public void setLlName(String aLlName);

//   public String getPalName();
//   public void setPalName(String aPalName);

//   public String getDescription();
//   public void setDescription(String aDescription);

//   public String getLanguage();
//   public void setLanguage(String aLanguage);
  
//   public Object clone() throws CloneNotSupportedException ;
}