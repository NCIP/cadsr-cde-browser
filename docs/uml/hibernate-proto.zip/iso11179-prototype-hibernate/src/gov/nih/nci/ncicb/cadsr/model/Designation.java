package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.class 
 *      table="DESIGNATIONS"
 */
public class Designation {

  private String id;
  private Context context;
  private String name;
  private String type;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *    column="DESIG_IDSEQ"
   *    generator-class="native"
   */
  public String getId() {
    return id;
  }

  /**
   * Get the Context value.
   * @return the Context value.
   *
   *
   * @hibernate.many-to-one 
   * 		column="CONTE_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.Context"
   */
  public Context getContext() {
    return context;
  }

  /**
   * Get the Name value.
   * @return the Name value.
   *
   * @hibernate.property
   *          column="NAME"
   *          length="30"
   */
  public String getName() {
    return name;
  }

  /**
   * Get the Type value.
   * @return the Type value.
   *
   * @hibernate.property
   *          column="DETL_NAME"
   *          length="20"
   */
  public String getType() {
    return type;
  }

  



  /**
   * Set the Type value.
   * @param newType The new Type value.
   */
  public void setType(String newType) {
    this.type = newType;
  }

  /**
   * Set the Name value.
   * @param newName The new Name value.
   */
  public void setName(String newName) {
    this.name = newName;
  }

  /**
   * Set the Context value.
   * @param newContext The new Context value.
   */
  public void setContext(Context newContext) {
    this.context = newContext;
  }

  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

}