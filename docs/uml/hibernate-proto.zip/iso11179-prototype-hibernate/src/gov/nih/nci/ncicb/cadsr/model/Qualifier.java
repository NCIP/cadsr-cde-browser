package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.class 
 *      table="QUALIFIER_LOV_EXT"
 */
public class Qualifier {

  private String name;

  private Audit audit;
  private String comments;
  private String description;

  /**
   * Get the Name value.
   * @return the Name value.
   *
   * @hibernate.id
   *    column="QUALIFIER_NAME"
   *    generator-class="native"
   */
  public String getName() {
    return name;
  }

  /**
   * Get the Audit value.
   * @return the Audit value.
   *
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }

  /**
   * Get the Comments value.
   * @return the Comments value.
   * 
   * @hibernate.property
   *    column="COMMENTS"
   *    type="string"
   *    length="200"
   */
  public String getComments() {
    return comments;
  }

  /**
   * Get the Description value.
   * @return the Description value.
   * 
   * @hibernate.property
   *    column="DESCRIPTION"
   *    type="string"
   *    length="60"
   */
  public String getDescription() {
    return description;
  }





  /**
   * Set the Description value.
   * @param newDescription The new Description value.
   */
  public void setDescription(String newDescription) {
    this.description = newDescription;
  }

  /**
   * Set the Comments value.
   * @param newComments The new Comments value.
   */
  public void setComments(String newComments) {
    this.comments = newComments;
  }

  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  /**
   * Set the Name value.
   * @param newName The new Name value.
   */
  public void setName(String newName) {
    this.name = newName;
  }

}