package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import net.sf.hibernate.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.ValueDomainDAO;
import gov.nih.nci.ncicb.cadsr.model.*;

public class ValueDomainDAOImpl extends HibernateDaoSupport implements ValueDomainDAO {

  public List findByNameLike(String name) {
    return getHibernateTemplate().findByNamedQuery("vd.findByNameLike", name);
  }

  public ValueDomain findByName(String name) {
    return (ValueDomain)getHibernateTemplate().findByNamedQuery("vd.findByName", name).get(0);
  }

  public List find(final ValueDomain o) {
    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  Criteria criteria = session.createCriteria(o.getClass());

	  AdminComponentQueryBuilder.buildCriteria(criteria, o);

	  return criteria.list();
	}
      };

    return (List)getHibernateTemplate().execute(callback);

  }

  public List getPermissibleValues(final String pk) {

    HibernateCallback callback = new HibernateCallback(){
	
	public Object doInHibernate(Session session) throws HibernateException, SQLException {
	  
	  Query query = session.getNamedQuery("vd.findByPK");
	  query.setString(0, pk);

	  ValueDomain vd = (ValueDomain)query.list().get(0);
	  List vd_pvs = vd.getValueDomainPermissibleValues();

	  List result = new ArrayList();
	  for(int i=0; i<vd_pvs.size(); i++) {
	    result.add(((ValueDomainPermissibleValue)vd_pvs.get(i)).getPermissibleValue());
	  }
	  
	  return result;
	}
	
      };
      
    return (List)getHibernateTemplate().execute(callback);
   
  } 
}