package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.AdminComponent;

import java.util.List;

public interface AdminComponentDAO {

  public List getClassificationScheme(AdminComponent ac);

}