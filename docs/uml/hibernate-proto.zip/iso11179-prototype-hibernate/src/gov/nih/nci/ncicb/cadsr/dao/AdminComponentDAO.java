package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.AdminComponent;

import java.util.List;

public interface AdminComponentDAO {

  public List getClassificationSchemes(AdminComponent ac);

  public String create(AdminComponent ac);

//   public void delete(AdminComponent ac);

  public void setDeleted(AdminComponent ac);

  public void update(AdminComponent ac);


}