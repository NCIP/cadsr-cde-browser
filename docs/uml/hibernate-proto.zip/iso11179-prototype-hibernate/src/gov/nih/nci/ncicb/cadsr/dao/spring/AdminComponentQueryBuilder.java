package gov.nih.nci.ncicb.cadsr.dao.spring;

import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;

import gov.nih.nci.ncicb.cadsr.model.AdminComponent;

public class AdminComponentQueryBuilder {

  public static Criteria buildCriteria(Criteria criteria, AdminComponent ac) {
    
    if(ac.getLongName() != null) {
      criteria.add(Expression.like("longName", ac.getLongName()));
    }
    if(ac.getContext() != null) {
      if(ac.getContext().getId() != null) {
	criteria.add(Expression.eq("context.id", ac.getContext().getId()));
      }
    }

    if(ac.getLatestVersionIndicator() != null) {
      if(ac.getLatestVersionIndicator().equalsIgnoreCase(AdminComponent.LATEST_VERSION_IND_YES)) {
	criteria.add(Expression.sql("{alias}.LATEST_VERSION_IND = '" + AdminComponent.LATEST_VERSION_IND_YES + "'"));
      }
    }
      

    return criteria;

  }

}