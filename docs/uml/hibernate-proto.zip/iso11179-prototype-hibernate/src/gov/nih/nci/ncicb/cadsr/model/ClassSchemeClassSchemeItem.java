package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.class table="CS_CSI"
 * 
 */
public class ClassSchemeClassSchemeItem {

  private String csCsiId;
  private String label;
  private Integer displayOrder;
  private Audit audit;
  private ClassificationSchemeItem csi;
  private ClassificationScheme cs;

  /**
   * Get the CsCsiId value.
   * @return the CsCsiId value.
   *
   * @hibernate.id
   *      column="CS_CSI_IDSEQ"
   *      generator-class="native"
   * 
   */
  public String getCsCsiId() {
    return csCsiId;
  }


  /**
   * Get the Label value.
   * @return the Label value.
   * 
   * @hibernate.property
   *            column="LABEL"
   *            type="string"
   *            length="30"
   */
  public String getLabel() {
    return label;
  }


  /**
   * Get the DisplayOrder value.
   * @return the DisplayOrder value.
   * 
   * @hibernate.property
   *            column="DISPLAY_ORDER"
   *            type="int"
   */
  public Integer getDisplayOrder() {
    return displayOrder;
  }


  /**
   * Get the Audit value.
   * @return the Audit value.
   * @hibernate.component
   *           class="gov.nih.nci.ncicb.cadsr.model.Audit"
   */
  public Audit getAudit() {
    return audit;
  }


  /**
   * Get the Csi value.
   * @return the Csi value.
   *
   * @hibernate.many-to-one 
   * 		column="CSI_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ClassificationSchemeItem"
   * 
   */
  public ClassificationSchemeItem getCsi() {
    return csi;
  }


  /**
   * Get the Cs value.
   * @return the Cs value.
   *
   * @hibernate.many-to-one 
   * 		column="CS_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ClassificationScheme"
   * 
   */
  public ClassificationScheme getCs() {
    return cs;
  }

  /**
   * Set the Cs value.
   * @param newCs The new Cs value.
   */
  public void setCs(ClassificationScheme newCs) {
    this.cs = newCs;
  }

  

  /**
   * Set the Csi value.
   * @param newCsi The new Csi value.
   */
  public void setCsi(ClassificationSchemeItem newCsi) {
    this.csi = newCsi;
  }


  /**
   * Set the Audit value.
   * @param newAudit The new Audit value.
   */
  public void setAudit(Audit newAudit) {
    this.audit = newAudit;
  }

  

  /**
   * Set the DisplayOrder value.
   * @param newDisplayOrder The new DisplayOrder value.
   */
  public void setDisplayOrder(Integer newDisplayOrder) {
    this.displayOrder = newDisplayOrder;
  }

  
  /**
   * Set the Label value.
   * @param newLabel The new Label value.
   */
  public void setLabel(String newLabel) {
    this.label = newLabel;
  }

  

  /**
   * Set the CsCsiId value.
   * @param newCsCsiId The new CsCsiId value.
   */
  public void setCsCsiId(String newCsCsiId) {
    this.csCsiId = newCsCsiId;
  }

  

}