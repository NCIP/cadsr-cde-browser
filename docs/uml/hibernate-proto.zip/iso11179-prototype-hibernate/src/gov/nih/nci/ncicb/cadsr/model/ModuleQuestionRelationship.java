package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.subclass 
 *            discriminator-value="MODULE_ELEMENT"
 *
 */
public class ModuleQuestionRelationship extends ContentObjectRelationship {

}