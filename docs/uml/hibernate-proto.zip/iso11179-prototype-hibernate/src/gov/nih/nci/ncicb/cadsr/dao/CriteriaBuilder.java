package gov.nih.nci.ncicb.cadsr.dao;

import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;

public interface CriteriaBuilder {

  public void populate(Criteria criteria);

}