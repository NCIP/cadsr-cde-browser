package gov.nih.nci.ncicb.cadsr.model;

/**
 * @hibernate.subclass 
 *            discriminator-value="FORM_INSTR"
 * 
 */
public class CRFInstruction extends ContentObject {



}