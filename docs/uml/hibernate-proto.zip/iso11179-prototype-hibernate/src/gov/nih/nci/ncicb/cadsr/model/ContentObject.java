package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class 
 *      table="QUEST_CONTENTS_EXT"
 *
 * @hibernate.discriminator column="QTL_NAME"
 * 
 * @hibernate.query name="co.findByPK"
 *            query="from ContentObject as co where co.id=?"
 */
public class ContentObject extends AdminComponent {

  private String id;

  private List relatedObjects;

  /**
   * Get the Id value.
   * @return the Id value.
   *
   * @hibernate.id
   *           column="QC_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   */
  public String getId() {
    return id;
  }


  /**
   * Get the RelatedObjects value.
   * @return the RelatedObjects value.
   * 
   * @hibernate.bag  
   *            name="relatedObjects"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="P_QC_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ContentObjectRelationship"
   * 
   */
  public List getRelatedObjects() {
    return relatedObjects;
  }

  /**
   * Set the RelatedObjects value.
   * @param newRelatedObjects The new RelatedObjects value.
   */
  public void setRelatedObjects(List newRelatedObjects) {
    this.relatedObjects = newRelatedObjects;
  }

  public void setId(String newId) {
    this.id = newId;
  }

  

}