package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.class
 *           table="PROPERTIES_EXT"
 */
public class Property extends AdminComponent {

  private String propId;
  private String definitionSource;

  /**
   *
   * @hibernate.id
   *           column="PROP_IDSEQ"
   *           generator-class="native"
   * 
   */
  public String getPropId() {
    return propId;
  }



  /**
   * Get the DefinitionSource value.
   * @return the DefinitionSource value.
   *
   * @hibernate.property
   *    column="DEFINITION_SOURCE"
   *    type="string"
   *    length="2000"
   */
  public String getDefinitionSource() {
    return definitionSource;
  }


  /**
   * Set the DefinitionSource value.
   * @param newDefinitionSource The new DefinitionSource value.
   */
  public void setDefinitionSource(String newDefinitionSource) {
    this.definitionSource = newDefinitionSource;
  }

  

  /**
   */
  public void setPropId(String newPropId) {
    this.propId = newPropId;
  }

  

}
