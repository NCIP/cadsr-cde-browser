package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.ObjectClass;

import java.util.List;

public interface ObjectClassDAO {

//   public List findByLongName(String name);

  public List find(ObjectClass de);

}