package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;
/**
 *
 * @hibernate.class
 *           table="DATA_ELEMENT_CONCEPTS"
 */
public class DataElementConcept extends AdminComponent
{
  private String decId;
  private ConceptualDomain conceptualDomain;
  private List dataElements;

  private ObjectClass objectClass;
  private Property property;


  /**
   * Get the DecId value.
   * @return the DeId value.
   *
   * @hibernate.id
   *           column="DEC_IDSEQ"
   *           generator-class="native"
   */
  public String getDecId() {
    return decId;
  }

  /**
   * Get the ConceptualDomain value.
   * @return the ConceptualDomain value.
   */
  public ConceptualDomain getConceptualDomain() {
    return conceptualDomain;
  }


  /**
   * Get the DataElements value.
   * @return the DataElements value.
   * 
   * @hibernate.bag  
   *            name="dataElements"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="DEC_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElement"
   * 
   */
  public List getDataElements() {
    return dataElements;
  }


  /**
   * Get the ObjectClass value.
   * @return the ObjectClass value.
   *
   * @hibernate.many-to-one 
   * 		column="OC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ObjectClass"
   *            not-null="false"
   * 
   */
  public ObjectClass getObjectClass() {
    return objectClass;
  }


  /**
   * Get the Property value.
   * @return the Property value.
   *
   * @hibernate.many-to-one 
   * 		column="PROP_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.Property"
   *            not-null="false"
   * 
   */
  public Property getProperty() {
    return property;
  }

  /**
   * Set the Property value.
   * @param newProperty The new Property value.
   */
  public void setProperty(Property newProperty) {
    this.property = newProperty;
  }

  

  /**
   * Set the ObjectClass value.
   * @param newObjectClass The new ObjectClass value.
   */
  public void setObjectClass(ObjectClass newObjectClass) {
    this.objectClass = newObjectClass;
  }

  

  /**
   * Set the DataElements value.
   * @param newDataElements The new DataElements value.
   */
  public void setDataElements(List newDataElements) {
    this.dataElements = newDataElements;
  }
  

  /**
   * Set the ConceptualDomain value.
   * @param newConceptualDomain The new ConceptualDomain value.
   */
  public void setConceptualDomain(ConceptualDomain newConceptualDomain) {
    this.conceptualDomain = newConceptualDomain;
  }
  


  /**
   * Set the DecId value.
   * @param newDecId The new DecId value.
   */
  public void setDecId(String newDecId) {
    this.decId = newDecId;
  }

//    public String getProplName();
//    public void setProplName(String aProplName);

//    public String getOclName();
//    public void setOclName(String aOclName);
   
//    public String getObjClassQualifier();
//    public void setObjClassQualifier(String aObjClassQualifier);

//    public String getPropertyQualifier();
//    public void setPropertyQualifier(String aPropertyQualifier);

//    public String getChangeNote();
//    public void setChangeNote(String aChangeNote);
//    public String getObjClassPrefName();

//    public String getObjClassContextName();
//    public String getPropertyPrefName();

//    public String getPropertyContextName();
//    public Float getObjClassVersion();
//    public Float getPropertyVersion();
//    public String getContextName();
//    public String getCDContextName();
//    public String getCDPrefName();
//    public Float getCDVersion();
}