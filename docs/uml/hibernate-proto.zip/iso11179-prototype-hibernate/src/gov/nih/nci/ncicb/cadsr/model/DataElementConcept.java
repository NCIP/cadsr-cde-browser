package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;
/**
 *
 * @hibernate.class
 *           table="DATA_ELEMENT_CONCEPTS"
 *
 * @hibernate.query name="dec.findByPK" query="from DataElementConcept as dec where dec.id = ?"
 *
 */
public class DataElementConcept extends AdminComponent
{
  private String id;
  private ConceptualDomain conceptualDomain;
  private List dataElements;

  private ObjectClass objectClass;
  private Property property;

  private List relatedDECs;

  /**
   * Get the Id value.
   * @return the DeId value.
   *
   * @hibernate.id
   *           column="DEC_IDSEQ"
   *           generator-class="gov.nih.nci.ncicb.cadsr.hibernate.AcIdGenerator"
   */
  public String getId() {
    return id;
  }

  /**
   * Get the ConceptualDomain value.
   * @return the ConceptualDomain value.
   */
  public ConceptualDomain getConceptualDomain() {
    return conceptualDomain;
  }

  /**
   * Get the DataElements value.
   * @return the DataElements value.
   * 
   * @hibernate.bag  
   *            name="dataElements"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="DEC_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElement"
   * 
   */
  public List getDataElements() {
    return dataElements;
  }


  /**
   * Get the ObjectClass value.
   * @return the ObjectClass value.
   *
   * @hibernate.many-to-one 
   * 		column="OC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ObjectClass"
   *            not-null="false"
   * 
   */
  public ObjectClass getObjectClass() {
    return objectClass;
  }


  /**
   * Get the Property value.
   * @return the Property value.
   *
   * @hibernate.many-to-one 
   * 		column="PROP_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.Property"
   *            not-null="false"
   * 
   */
  public Property getProperty() {
    return property;
  }

  /**
   * Get the RelatedDECs value.
   * @return the RelatedDECs value.
   * 
   * @hibernate.bag  
   *            name="relatedDECs"
   * 		cascade="none"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="P_DEC_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElementConceptRelationship"
   * 
   */
  public List getRelatedDECs() {
    return relatedDECs;
  }

  /**
   * Set the RelatedDECs value.
   * @param newRelatedDECs The new RelatedDECs value.
   */
  public void setRelatedDECs(List newRelatedDECs) {
    this.relatedDECs = newRelatedDECs;
  }

  


  /**
   * Set the Property value.
   * @param newProperty The new Property value.
   */
  public void setProperty(Property newProperty) {
    this.property = newProperty;
  }

  

  /**
   * Set the ObjectClass value.
   * @param newObjectClass The new ObjectClass value.
   */
  public void setObjectClass(ObjectClass newObjectClass) {
    this.objectClass = newObjectClass;
  }

  

  /**
   * Set the DataElements value.
   * @param newDataElements The new DataElements value.
   */
  public void setDataElements(List newDataElements) {
    this.dataElements = newDataElements;
  }
  

  /**
   * Set the ConceptualDomain value.
   * @param newConceptualDomain The new ConceptualDomain value.
   */
  public void setConceptualDomain(ConceptualDomain newConceptualDomain) {
    this.conceptualDomain = newConceptualDomain;
  }
  


  /**
   * Set the Id value.
   * @param newId The new Id value.
   */
  public void setId(String newId) {
    this.id = newId;
  }

//    public String getProplName();
//    public void setProplName(String aProplName);

//    public String getOclName();
//    public void setOclName(String aOclName);
   
//    public String getObjClassQualifier();
//    public void setObjClassQualifier(String aObjClassQualifier);

//    public String getPropertyQualifier();
//    public void setPropertyQualifier(String aPropertyQualifier);

//    public String getChangeNote();
//    public void setChangeNote(String aChangeNote);
//    public String getObjClassPrefName();

//    public String getObjClassContextName();
//    public String getPropertyPrefName();

//    public String getPropertyContextName();
//    public Float getObjClassVersion();
//    public Float getPropertyVersion();
//    public String getContextName();
//    public String getCDContextName();
//    public String getCDPrefName();
//    public Float getCDVersion();
}