package gov.nih.nci.ncicb.cadsr.dao.spring;

import java.util.List;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;
import org.springframework.orm.hibernate.HibernateCallback;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;

import gov.nih.nci.ncicb.cadsr.dao.BaseDAO;
import gov.nih.nci.ncicb.cadsr.dao.CriteriaBuilder;

public class BaseDAOImpl extends HibernateDaoSupport implements BaseDAO {

//   public List findByCriteria(final CriteriaBuilder criteriaBuilder) {

//     final Class clazz = this.getClass();

//     HibernateCallback callback = new HibernateCallback(){
	
// 	public Object doInHibernate(Session session) throws HibernateException {
// 	  System.out.println("BaseDAOImpl Class: " + clazz);
// 	  Criteria criteria = session.createCriteria(clazz);
// 	  criteriaBuilder.populate(criteria);
// 	  return criteria.list();
// 	}
//       };

//     return (List)getHibernateTemplate().execute(callback);
    
//   }


}