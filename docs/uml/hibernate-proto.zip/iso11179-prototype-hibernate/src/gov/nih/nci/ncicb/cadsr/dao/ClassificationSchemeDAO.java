package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.ClassificationScheme;

import java.util.List;

public interface ClassificationSchemeDAO {

  public List find(ClassificationScheme o);

  public List getCsis(String pk);

}