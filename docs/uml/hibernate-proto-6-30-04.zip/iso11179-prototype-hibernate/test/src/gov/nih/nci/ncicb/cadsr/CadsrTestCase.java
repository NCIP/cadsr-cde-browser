package gov.nih.nci.ncicb.cadsr;

import junit.framework.*;

import junit.textui.TestRunner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gov.nih.nci.ncicb.cadsr.spring.ApplicationContextFactory;

import gov.nih.nci.ncicb.cadsr.dao.*;

public class CadsrTestCase extends TestCase 
{

  static {
    ApplicationContextFactory.init("applicationContext.xml");
  }

  public CadsrTestCase() {
    super();
  }

  public CadsrTestCase(String name) {
    super(name);
  }


  public static Test suite()
  {
    TestSuite suite = new TestSuite();
    suite.addTest(new ContextDAOTest("testFindAllContexts"));
    suite.addTest(new ContextDAOTest("testFindByName"));
    suite.addTest(new ValueDomainDAOTest("testFindByNameLike"));
    return suite;
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) {
//     TestRunner.run(CadsrTestCase.class);
    ContextDAOTest.main(args);
    ValueDomainDAOTest.main(args);
    DataElementDAOTest.main(args);
    ObjectClassDAOTest.main(args);
    PropertyDAOTest.main(args);
  }
  
}