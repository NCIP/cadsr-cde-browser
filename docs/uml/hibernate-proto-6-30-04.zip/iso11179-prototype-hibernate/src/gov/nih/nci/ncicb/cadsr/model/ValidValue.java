package gov.nih.nci.ncicb.cadsr.model;

public class ValidValue {

  String vvId;

  /**
   * Get the VvId value.
   * @return the VvId value.
   */
  public String getVvId() {
    return vvId;
  }

  /**
   * Set the VvId value.
   * @param newVvId The new VvId value.
   */
  public void setVvId(String newVvId) {
    this.vvId = newVvId;
  }

//   public String getShortMeaning();

//   public void setShortMeaning(String aShortMeaning);

//   public String getShortMeaningDescription();

//   public void setShortMeaningDescription(String aShortMeaningDescription);

//   public String getShortMeaningValue();

//   public void setShortMeaningValue(String aShortMeaningValue);

//   public String getDescription();

//   public void setDescription(String vmDescription);

//   public String getVpIdseq();

//   public void setVpIdseq(String aVpIdseq);
  
//   public Object clone() throws CloneNotSupportedException ;
}
