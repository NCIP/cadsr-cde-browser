package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.class
 *           table="DATA_ELEMENTS"
 * 
 */
public class DataElement extends AdminComponent{

  private String deId;
  private ValueDomain valueDomain;
  private DataElementConcept dataElementConcept;

  /**
   * Get the DeId value.
   * @return the DeId value.
   *
   * @hibernate.id
   *           column="DE_IDSEQ"
   *           generator-class="native"
   */
  public String getDeId() {
    return deId;
  }

  /**
   * Get the DataElementConcept value.
   * @return the DataElementConcept value.
   *
   * @hibernate.many-to-one 
   * 		column="DEC_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.DataElementConcept"
   * 
   */
  public DataElementConcept getDataElementConcept() {
    return dataElementConcept;
  }

  /**
   * Get the ValueDomain value.
   * @return the ValueDomain value.
   *
   * @hibernate.many-to-one 
   * 		column="VD_IDSEQ" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ValueDomain"
   */
  public ValueDomain getValueDomain() {
    return valueDomain;
  }


  /**
   * Set the DataElementConcept value.
   * @param newDataElementConcept The new DataElementConcept value.
   */
  public void setDataElementConcept(DataElementConcept newDataElementConcept) {
    this.dataElementConcept = newDataElementConcept;
  }

  /**
   * Set the DeId value.
   * @param newDeId The new DeId value.
   */
  public void setDeId(String newDeId) {
    this.deId = newDeId;
  }

  /**
   * Set the ValueDomain value.
   * @param newValueDomain The new ValueDomain value.
   */
  public void setValueDomain(ValueDomain newValueDomain) {
    this.valueDomain = newValueDomain;
  }


//   public String getCDEId();
//   public String getDecName();
  
//   public void setLongCDEName (String pLongCDEName);
//   public void setContextName(String pConteName);
//   public void setCDEId(String pCDEId);
  
//   public String getUsingContexts();
//   public void setUsingContexts(String usingContexts);
  
}
