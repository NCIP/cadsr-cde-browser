package gov.nih.nci.ncicb.cadsr.model;

import java.util.Date;

public class Lifecycle {

  private Date beginDate;
  private Date endDate;

  /**
   * Get the EndDate value.
   * @return the EndDate value.
   *
   * @hibernate.property
   *     column="END_DATE"
   *     type="date"
   *     not-null="false"
   */
  public Date getEndDate() {
    return endDate;
  }

  /**
   * Set the EndDate value.
   * @param newEndDate The new EndDate value.
   */
  public void setEndDate(Date newEndDate) {
    this.endDate = newEndDate;
  }

  

  /**
   * Get the BeginDate value.
   * @return the BeginDate value.
   *
   * @hibernate.property
   *     column="BEGIN_DATE"
   *     type="date"
   *     not-null="false"
   */
  public Date getBeginDate() {
    return beginDate;
  }

  /**
   * Set the BeginDate value.
   * @param newBeginDate The new BeginDate value.
   */
  public void setBeginDate(Date newBeginDate) {
    this.beginDate = newBeginDate;
  }
}