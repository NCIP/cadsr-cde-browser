package gov.nih.nci.ncicb.cadsr.dao.spring;

import net.sf.hibernate.*;
import net.sf.hibernate.expression.*;

import gov.nih.nci.ncicb.cadsr.model.AdminComponent;

public class AdminComponentQueryBuilder {

  public static Criteria buildCriteria(Criteria criteria, AdminComponent ac) {
    
    if(ac.getLongName() != null) {
      criteria.add(Expression.like("longName", ac.getLongName()));
    }
    if(ac.getContext() != null) {
      if(ac.getContext().getContextId() != null) {
	criteria.add(Expression.eq("context.contextId", ac.getContext().getContextId()));
      }
    }
    return criteria;

  }

}