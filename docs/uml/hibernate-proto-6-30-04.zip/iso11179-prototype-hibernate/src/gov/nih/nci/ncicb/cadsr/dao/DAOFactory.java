package gov.nih.nci.ncicb.cadsr.dao;

public class DAOFactory {

  public static ContextDAO createContextDAO() {
    return new gov.nih.nci.ncicb.cadsr.dao.spring.ContextDAOImpl();
  }

}