package gov.nih.nci.ncicb.cadsr.model;

/**
 *
 * @hibernate.class
 *           table="DATA_ELEMENT_CONCEPTS"
 */
public class DataElementConcept extends AdminComponent
{
  private String decId;
  private ConceptualDomain conceptualDomain;


  /**
   * Get the DecId value.
   * @return the DeId value.
   *
   * @hibernate.id
   *           column="DEC_IDSEQ"
   *           generator-class="native"
   */
  public String getDecId() {
    return decId;
  }

  /**
   * Get the ConceptualDomain value.
   * @return the ConceptualDomain value.
   */
  public ConceptualDomain getConceptualDomain() {
    return conceptualDomain;
  }

  /**
   * Set the ConceptualDomain value.
   * @param newConceptualDomain The new ConceptualDomain value.
   */
  public void setConceptualDomain(ConceptualDomain newConceptualDomain) {
    this.conceptualDomain = newConceptualDomain;
  }
  


  /**
   * Set the DecId value.
   * @param newDecId The new DecId value.
   */
  public void setDecId(String newDecId) {
    this.decId = newDecId;
  }

//    public String getProplName();
//    public void setProplName(String aProplName);

//    public String getOclName();
//    public void setOclName(String aOclName);
   
//    public String getObjClassQualifier();
//    public void setObjClassQualifier(String aObjClassQualifier);

//    public String getPropertyQualifier();
//    public void setPropertyQualifier(String aPropertyQualifier);

//    public String getChangeNote();
//    public void setChangeNote(String aChangeNote);
//    public String getObjClassPrefName();

//    public String getObjClassContextName();
//    public String getPropertyPrefName();

//    public String getPropertyContextName();
//    public Float getObjClassVersion();
//    public Float getPropertyVersion();
//    public String getContextName();
//    public String getCDContextName();
//    public String getCDPrefName();
//    public Float getCDVersion();
}