package gov.nih.nci.ncicb.cadsr.model;

import java.util.List;

/**
 * @hibernate.class 
 *      table="PERMISSIBLE_VALUES"
 */
public class PermissibleValue {

  private String pvId;
  private String value;
  private Integer lowValue;
  private Integer highValue;

  private ValueMeaning valueMeaning;
  private List valueDomainPermissibleValues;

  /**
   * Get the PvId value.
   * @return the PvId value.
   *
   * @hibernate.id
   *    column="PV_IDSEQ"
   *    generator-class="native"
   */
  public String getPvId() {
    return pvId;
  }


  /**
   * Get the ValueMeaning value.
   * @return the ValueMeaning value.
   *
   * @hibernate.many-to-one 
   * 		column="SHORT_MEANING" 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ValueMeaning"
   * 
   */
  public ValueMeaning getValueMeaning() {
    return valueMeaning;
  }

  /**
   * Get the HighValue value.
   * @return the HighValue value.
   *
   * @hibernate.property
   *    column="HIGH_VALUE_NUM"
   */
  public Integer getHighValue() {
    return highValue;
  }

  /**
   * Get the LowValue value.
   * @return the LowValue value.
   *
   * @hibernate.property
   *    column="LOW_VALUE_NUM"
   */
  public Integer getLowValue() {
    return lowValue;
  }

  
  /**
   * Get the Value value.
   * @return the Value value.
   *
   * @hibernate.property
   *    column="VALUE"
   *    length="255"

   */
  public String getValue() {
    return value;
  }


  /**
   * Get the ValueDomainPermissibleValues value.
   * @return the ValueDomainPermissibleValues value.
   * 
   * @hibernate.bag  
   *            name="valueDomainPermissibleValues"
   * 		cascade="save-update"
   * 		lazy="true"
   * 		inverse="true"
   * 
   * @hibernate.collection-key 
   * 		column="PV_IDSEQ"
   * 
   * @hibernate.collection-one-to-many 
   * 		class="gov.nih.nci.ncicb.cadsr.model.ValueDomainPermissibleValue"
   * 
   */
  public List getValueDomainPermissibleValues() {
    return valueDomainPermissibleValues;
  }





  /**
   * Set the ValueDomainPermissibleValues value.
   * @param newValueDomainPermissibleValues The new ValueDomainPermissibleValues value.
   */
  public void setValueDomainPermissibleValues(List newValueDomainPermissibleValues) {
    this.valueDomainPermissibleValues = newValueDomainPermissibleValues;
  }

  

  /**
   * Set the PvId value.
   * @param newPvId The new PvId value.
   */
  public void setPvId(String newPvId) {
    this.pvId = newPvId;
  }

  /**
   * Set the Value value.
   * @param newValue The new Value value.
   */
  public void setValue(String newValue) {
    this.value = newValue;
  }

  /**
   * Set the LowValue value.
   * @param newLowValue The new LowValue value.
   */
  public void setLowValue(Integer newLowValue) {
    this.lowValue = newLowValue;
  }
  
  /**
   * Set the ValueMeaning value.
   * @param newValueMeaning The new ValueMeaning value.
   */
  public void setValueMeaning(ValueMeaning newValueMeaning) {
    this.valueMeaning = newValueMeaning;
  }

  /**
   * Set the HighValue value.
   * @param newHighValue The new HighValue value.
   */
  public void setHighValue(Integer newHighValue) {
    this.highValue = newHighValue;
  }
  

}