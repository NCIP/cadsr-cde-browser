package gov.nih.nci.ncicb.cadsr.dao;

import gov.nih.nci.ncicb.cadsr.model.DataElement;

import java.util.List;

public interface DataElementDAO {

//   public List findByLongName(String name);

  public List find(DataElement de);

}