package gov.nih.nci.ncicb.cadsr.model;

public class ConceptualDomain extends AdminComponent
{

}