package gov.nih.nci.ncicb.cadsr.hibernate;

import java.io.Serializable;

import net.sf.hibernate.id.IdentifierGenerator;
import net.sf.hibernate.engine.SessionImplementor;

public class AcIdGenerator implements IdentifierGenerator {
  
  public Serializable generate(SessionImplementor session, Object object) {
    return null;
  }
  
}