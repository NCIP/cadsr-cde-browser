package gov.nih.nci.ncicb.cadsr.admintool.struts.actions;

import gov.nih.nci.ncicb.cadsr.domain.Context;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import gov.nih.nci.ncicb.cadsr.admintool.struts.common.*;

import java.util.List;

public class GetContextAction extends BaseAction  {

    public String contextName = "abc";
    public static String conteName;

    public ActionForward executeAction(
    ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response) throws IOException, ServletException {
    Context conte = (Context) this.getContextService().getAllContexts().get(2);
    conteName = ((Context) conte).getName();
    return mapping.findForward("success");

  }


}