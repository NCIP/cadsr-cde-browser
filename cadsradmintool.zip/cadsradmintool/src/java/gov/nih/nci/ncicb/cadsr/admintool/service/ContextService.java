package gov.nih.nci.ncicb.cadsr.admintool.service;
import gov.nih.nci.ncicb.cadsr.dao.ContextDAO;
import java.util.List;

public interface ContextService  {


    /**
     * @return
     */
    public List getAllContexts();
}