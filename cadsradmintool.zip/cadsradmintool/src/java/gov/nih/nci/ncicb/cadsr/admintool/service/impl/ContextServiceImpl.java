package gov.nih.nci.ncicb.cadsr.admintool.service.impl;

import gov.nih.nci.ncicb.cadsr.admintool.service.ContextService;
import gov.nih.nci.ncicb.cadsr.dao.ContextDAO;
import java.util.List;

import gov.nih.nci.ncicb.cadsr.dao.AbstractDAOFactory;


public class ContextServiceImpl extends BaseServiceImpl implements ContextService  {
    AbstractDAOFactory daoFactory = null;

  public ContextServiceImpl() {
  }

  public List getAllContexts() {
    ContextDAO contextDAO = daoFactory.getContextDAO();
    return contextDAO.findAll();
  }
}