package gov.nih.nci.ncicb.cadsr.admintool.service.impl;

import gov.nih.nci.ncicb.cadsr.dao.AbstractDAOFactory;


public class BaseServiceImpl  {

    AbstractDAOFactory daoFactory = null;

  public BaseServiceImpl() {
  }

  public void setDaoFactory(AbstractDAOFactory daoFactory)
  {
	  this.daoFactory=daoFactory;
  }

  public AbstractDAOFactory getDaoFactory()
  {
	  return this.daoFactory;
  }

}