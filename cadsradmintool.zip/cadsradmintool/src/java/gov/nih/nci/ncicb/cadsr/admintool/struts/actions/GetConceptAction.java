package admintool.action;


import gov.nih.nci.ncicb.cadsr.domain.Concept;
import gov.nih.nci.ncicb.cadsr.dao.ConceptDAO;
import gov.nih.nci.ncicb.cadsr.domain.DomainObjectFactory;
import gov.nih.nci.ncicb.cadsr.domain.bean.ConceptBean;
import gov.nih.nci.ncicb.cadsr.service.ConceptService;
import java.util.Date;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetConceptAction extends BaseAction{  
   
    public static String preferredName;
    public static Concept c =(Concept) DomainObjectFactory.newConcept(); 
    public static Concept cd =(Concept) DomainObjectFactory.newConcept();  
    
  public ActionForward executeAction(
    ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response) throws IOException, ServletException {
    
    
    try {      
      
      cd.setId("EDD00331-16B9-61BF-E034-0003BA0B1A09");
      c = this.getConceptService().findConcept(c) ;
      //preferredName = c.getPreferredName();
    }
    catch (Exception e) {
    System.out.println("there is an error");
      
    }
    
    return mapping.findForward("success");
  }
  
 
  
      
}