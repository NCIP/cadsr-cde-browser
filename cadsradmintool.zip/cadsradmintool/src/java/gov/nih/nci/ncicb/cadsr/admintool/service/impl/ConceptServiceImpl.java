package gov.nih.nci.ncicb.cadsr.admintool.service.impl;

import gov.nih.nci.ncicb.cadsr.dao.AbstractDAOFactory;
import gov.nih.nci.ncicb.cadsr.dao.ConceptDAO;
import gov.nih.nci.ncicb.cadsr.domain.Concept;
import gov.nih.nci.ncicb.cadsr.admintool.service.ConceptService;
import gov.nih.nci.ncicb.cadsr.dao.ContextDAO;

import java.util.List;

public class ConceptServiceImpl extends BaseServiceImpl implements ConceptService  {
   

  public ConceptServiceImpl() {
  }

  public Concept findConcept(Concept c) throws Exception {
      ConceptDAO conceptDAO = daoFactory.getConceptDAO();
    return (Concept) conceptDAO.find(c).get(0);
  }
}