package gov.nih.nci.ncicb.cadsr.admintool.struts.actions;

import gov.nih.nci.ncicb.cadsr.admintool.struts.common.*;

public class TestAction {
    public TestAction() {
    }
}
