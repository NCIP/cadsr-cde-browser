package gov.nih.nci.ncicb.cadsr.admintool.struts;

public class TestAction {
    public TestAction() {
    }
}
