package admintool.action;

import gov.nih.nci.ncicb.cadsr.dao.hibernate.ConceptDAOImpl;
import gov.nih.nci.ncicb.cadsr.domain.Concept;
import gov.nih.nci.ncicb.cadsr.domain.Context;
import gov.nih.nci.ncicb.cadsr.domain.bean.ConceptBean;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class TestConcept  extends BaseAction{
  public TestConcept() { 
  }
  public static String preferredName;
  
  public void Test(){
  ConceptBean cdb= new ConceptBean();
  Context conte = (Context) this.getContextService().getAllContexts().get(2);
  cdb.setPreferredName("testCreate");
  cdb.setLongName("testCreate");
  cdb.setPreferredDefinition("test Create Definition");
  cdb.setWorkflowStatus("DRAFT NEW");
  cdb.setContext(conte);

  Concept cd = (Concept) cdb;
  ConceptDAOImpl cdDAO = new ConceptDAOImpl();
  String x = cdDAO.create(cdb);
  System.out.println("data created");
  Concept cd2 = (Concept) cdDAO.find(cd).get(1);
  preferredName=cd2.getPreferredName();
    
  }
  
   public ActionForward executeAction(
    ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response) throws IOException, ServletException {
    return mapping.findForward("success");

  }
}